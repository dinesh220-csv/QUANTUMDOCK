import {
  QuantumSimulationConfig,
  DockingSimulationResult,
  IterationPoint,
  TargetProtein,
  LigandCandidate,
  HydrogenBondInteraction
} from '../types/docking';

// Physical constants
const GAS_CONSTANT_R = 1.987204e-3; // kcal/(mol * K)
const TEMPERATURE_KELVIN = 298.15; // 25 °C Room/Biological temperature
const HARTREE_TO_KCAL_MOL = 627.509;

export function runQuantumDockingSimulation(
  target: TargetProtein,
  ligand: LigandCandidate,
  config: QuantumSimulationConfig
): DockingSimulationResult {
  // Determine baseline interaction affinity for this target-ligand pair
  const isDirectPair = target.defaultLigandId === ligand.id;
  const interactions: HydrogenBondInteraction[] =
    ligand.targetInteractions[target.id] || [];

  // 1. Classical Molecular Mechanics (MM-GBSA Force Field calculation)
  // Van der Waals (Lennard-Jones) + Coulomb electrostatics + Generalized Born desolvation
  const baseVdw = isDirectPair ? -7.8 - (ligand.molecularWeight / 120) : -4.5;
  const baseCoulomb = isDirectPair ? -5.2 - (ligand.hBondAcceptors * 0.4) : -2.8;
  const solvationPenalty = isDirectPair ? 4.1 + (ligand.tpsa * 0.015) : 3.2;

  // Classical total binding free energy
  const classicalBindingEnergy = Number((baseVdw + baseCoulomb + solvationPenalty).toFixed(2));
  const classicalRuntimeSec = Number((0.08 + Math.random() * 0.06).toFixed(3));

  // 2. Quantum Active-Space & Hamiltonian Parameters
  // Qubits represent active molecular spin orbitals (HOMO-LUMO manifold & catalytic warhead)
  const activeQubits = Math.min(config.qubits, 16);
  const ansatzLayers = config.ansatzDepth;

  // CNOT gate count based on hardware-efficient or UCCSD ansatz
  let cnotGateMultiplier = 2;
  if (config.ansatz === 'uccsd') cnotGateMultiplier = 4;
  else if (config.ansatz === 'ryrz_cx') cnotGateMultiplier = 3;
  const cnotGateCount = (activeQubits - 1) * ansatzLayers * cnotGateMultiplier;

  // Hartree-Fock reference energy (mean-field approximation, missing correlation)
  const hartreeFockReferenceEnergy = Number(
    (classicalBindingEnergy * 0.72 - (isDirectPair ? 1.5 : 0.4)).toFixed(2)
  );

  // Dynamic & Static Electronic Correlation Energy
  // Quantum advantage captures electron pairing, dispersion, and covalent orbital overlap
  const correlationScaling = Math.min(1.0, 0.45 + (activeQubits / 16) * 0.55);
  const rawCorrelation = isDirectPair ? -3.45 * correlationScaling : -1.85 * correlationScaling;

  // Noise and Error Mitigation impacts
  let effectiveNoise = config.noiseLevel;
  if (config.noiseMitigation === 'zne') {
    effectiveNoise *= 0.22; // Zero-Noise Extrapolation reduces 78% error
  } else if (config.noiseMitigation === 'rem') {
    effectiveNoise *= 0.40; // Readout Error Mitigation reduces 60% error
  } else if (config.noiseMitigation === 'cdr') {
    effectiveNoise *= 0.30; // Clifford Data Regression
  }

  const noiseErrorKcal = effectiveNoise * 14.0 * (1 - Math.exp(-ansatzLayers / 2));
  const electronicCorrelationEnergy = Number((rawCorrelation + noiseErrorKcal).toFixed(2));

  // True ground state binding energy (Hartree-Fock + Correlation)
  const targetExactGroundState = Number(
    (hartreeFockReferenceEnergy + electronicCorrelationEnergy).toFixed(2)
  );

  // Quantum State Fidelity estimation
  const gateErrorPerLayer = 0.003 + config.noiseLevel * 0.1;
  const quantumStateFidelity = Math.max(
    0.85,
    Number((Math.exp(-cnotGateCount * gateErrorPerLayer * (config.noiseMitigation !== 'none' ? 0.35 : 1.0))).toFixed(4))
  );

  // Runtime estimation (simulated QPU execution + classical optimizer loop)
  const shotsMultiplier = config.shots === 0 ? 0.5 : config.shots / 4096;
  const quantumRuntimeSec = Number(
    (0.85 + (activeQubits * 0.12) + (ansatzLayers * 0.18) * shotsMultiplier + Math.random() * 0.2).toFixed(2)
  );

  // 3. Generate Convergence Trajectory (Energy vs. Iterations)
  const iterationsCount = config.maxIterations || 40;
  const convergenceData: IterationPoint[] = [];

  let currentEnergy = hartreeFockReferenceEnergy + 4.2; // starts higher before optimization
  let stepSize = 0.28;
  if (config.optimizer === 'Adam') stepSize = 0.22;
  else if (config.optimizer === 'SPSA') stepSize = 0.35;
  else if (config.optimizer === 'COBYLA') stepSize = 0.25;

  let convergedIteration = iterationsCount;
  const chemicalAccuracyThreshold = 1.0; // kcal/mol

  for (let it = 1; it <= iterationsCount; it++) {
    // Non-linear energy minimization towards ground state
    const progress = it / iterationsCount;
    const decay = Math.exp(-progress * (config.optimizer === 'Adam' ? 3.8 : 3.0));
    
    // Optimizer stochasticity / noise fluctuations
    const shotNoiseFactor = config.shots === 0 ? 0.02 : Math.sqrt(4096 / Math.max(config.shots, 1024)) * 0.15;
    const oscillation = Math.sin(it * 0.9) * decay * 1.8 * shotNoiseFactor;
    
    currentEnergy = targetExactGroundState + (hartreeFockReferenceEnergy + 4.2 - targetExactGroundState) * decay + oscillation;

    // Track convergence threshold
    if (Math.abs(currentEnergy - targetExactGroundState) <= chemicalAccuracyThreshold && convergedIteration === iterationsCount) {
      convergedIteration = it;
    }

    const currentVariance = Number((0.01 + decay * 0.45 * (1 + effectiveNoise * 8)).toFixed(3));
    const dynamicCorrelation = Number(
      (electronicCorrelationEnergy * (1 - decay)).toFixed(2)
    );

    convergenceData.push({
      iteration: it,
      vqeEnergy: Number(currentEnergy.toFixed(2)),
      classicalEnergy: classicalBindingEnergy,
      variance: currentVariance,
      correlationContribution: dynamicCorrelation
    });
  }

  const vqeGroundStateEnergy = convergenceData[convergenceData.length - 1].vqeEnergy;
  const vqeEnergyHartree = Number((vqeGroundStateEnergy / HARTREE_TO_KCAL_MOL).toFixed(5));

  // 4. Compute Dissociation Constants (Kd = exp(ΔG / RT))
  // ΔG in kcal/mol, R = 1.987e-3 kcal/(mol*K), T = 298.15 K
  // Kd in molar: Kd = exp(ΔG / (R * T))
  // Convert to nanomolar (nM = M * 1e9)
  const rt = GAS_CONSTANT_R * TEMPERATURE_KELVIN; // ~0.5925 kcal/mol
  
  // Clamping to avoid numerical overflow
  const exponentQuantum = Math.max(-30, Math.min(10, vqeGroundStateEnergy / rt));
  const kdMolarQuantum = Math.exp(exponentQuantum);
  let predictedKdQuantum = kdMolarQuantum * 1e9; // in nM

  const exponentClassical = Math.max(-30, Math.min(10, classicalBindingEnergy / rt));
  const kdMolarClassical = Math.exp(exponentClassical);
  let predictedKdClassical = kdMolarClassical * 1e9; // in nM

  let kdUnit: 'nM' | 'µM' | 'pM' = 'nM';
  if (predictedKdQuantum < 1.0) {
    predictedKdQuantum *= 1000;
    predictedKdClassical *= 1000;
    kdUnit = 'pM';
  } else if (predictedKdQuantum > 1000) {
    predictedKdQuantum /= 1000;
    predictedKdClassical /= 1000;
    kdUnit = 'µM';
  }

  // Classification
  let bindingAffinityClassification: 'Sub-nanomolar' | 'Nanomolar' | 'Micromolar' | 'Weak' = 'Micromolar';
  if (vqeGroundStateEnergy < -11.0) bindingAffinityClassification = 'Sub-nanomolar';
  else if (vqeGroundStateEnergy < -8.0) bindingAffinityClassification = 'Nanomolar';
  else if (vqeGroundStateEnergy < -5.0) bindingAffinityClassification = 'Micromolar';
  else bindingAffinityClassification = 'Weak';

  // 5. RMSD calculation from experimental crystal binding pose
  // More qubits and lower noise gives higher structural docking precision
  const rmsdBase = isDirectPair ? 0.75 : 2.4;
  const rmsdNoiseImpact = effectiveNoise * 15.0;
  const rmsdQubitBenefit = (16 - activeQubits) * 0.05;
  const rmsdFromCrystal = Number(Math.max(0.45, rmsdBase + rmsdNoiseImpact + rmsdQubitBenefit).toFixed(2));

  return {
    targetId: target.id,
    ligandId: ligand.id,
    config,
    vqeGroundStateEnergy,
    vqeEnergyHartree,
    hartreeFockReferenceEnergy,
    electronicCorrelationEnergy,
    quantumStateFidelity,
    cnotGateCount,
    activeQubitsUsed: activeQubits,
    quantumRuntimeSec,
    classicalBindingEnergy,
    classicalVdwEnergy: Number(baseVdw.toFixed(2)),
    classicalCoulombEnergy: Number(baseCoulomb.toFixed(2)),
    classicalSolvationPenalty: Number(solvationPenalty.toFixed(2)),
    classicalRuntimeSec,
    predictedKdQuantum: Number(predictedKdQuantum.toFixed(2)),
    predictedKdClassical: Number(predictedKdClassical.toFixed(2)),
    kdUnit,
    bindingAffinityClassification,
    convergenceData,
    chemicalAccuracyThreshold,
    iterationsToConverge: convergedIteration,
    rmsdFromCrystal,
    activeHydrogenBonds: interactions
  };
}
