import { TargetProtein, LigandCandidate, HydrogenBondInteraction } from '../types/docking';

export const TARGET_PROTEINS: TargetProtein[] = [
  {
    id: 'sars-cov-2-mpro',
    name: 'SARS-CoV-2 Main Protease (Mpro / 3CLpro)',
    shortName: 'SARS-CoV-2 Mpro',
    pdbId: '7BQY',
    organism: 'Severe acute respiratory syndrome coronavirus 2',
    diseaseArea: 'Viral Infectious Disease (COVID-19)',
    resolution: '1.70 Å',
    description: 'Essential cysteine protease that cleaves the viral polyproteins pp1a and pp1ab at eleven conserved sites. Primary drug target for direct-acting antivirals.',
    bindingSiteDescription: 'Catalytic dyad Cys145-His41 in the cleft between Domain I and II, alongside S1 pocket (Glu166, Phe140) and S2 hydrophobic subpocket (Met49, Met165).',
    sequenceFasta: '>7BQY_1|Chain A|3C-like proteinase\nSGFRKMAFPSGKVEGCMVQVTCGTTTLNGLWLDDVVYCPRHVICTSEDMLNPNYEDLLIRKSNHNFLVQAGNVQLRVIGHSMQNCVLKLKVDTANPKTPKYKFVRIQPGQTFSVLACYNGSPSGVYQCAMRPNFTIKGSFLNGSCGSVGFNIDYDCVSFCYMHHMELPTGVHAGTDLEGNFYGPFVDRQTAQAAGTDTTITVNVLAWLYAAVINGDRWFLNRFTTTLNDFNLVAMKYNYEPLTQDHVDILGPLSAQTGIAVLDMCASLKELLQNGMNGRTILGSALLEDEFTPFDVVRQCSGVTFQ',
    defaultLigandId: 'nirmatrelvir',
    keyResidues: [
      { id: 'res-cys145', name: 'CYS', number: 145, chain: 'A', role: 'catalytic', x: 2.1, y: 1.2, z: 0.4, charge: 0 },
      { id: 'res-his41', name: 'HIS', number: 41, chain: 'A', role: 'catalytic', x: -1.9, y: 1.8, z: -0.6, charge: 1 },
      { id: 'res-glu166', name: 'GLU', number: 166, chain: 'A', role: 'binding_pocket', x: 3.4, y: -2.1, z: 1.1, charge: -1 },
      { id: 'res-gly143', name: 'GLY', number: 143, chain: 'A', role: 'binding_pocket', x: 1.1, y: 3.2, z: 0.9, charge: 0 },
      { id: 'res-gln189', name: 'GLN', number: 189, chain: 'A', role: 'hydrophobic_wall', x: -3.2, y: -1.4, z: 2.2, charge: 0 },
      { id: 'res-met165', name: 'MET', number: 165, chain: 'A', role: 'hydrophobic_wall', x: 0.2, y: -3.1, z: -1.8, charge: 0 },
      { id: 'res-asn142', name: 'ASN', number: 142, chain: 'A', role: 'binding_pocket', x: 2.8, y: 2.5, z: -1.2, charge: 0 },
    ]
  },
  {
    id: 'egfr-kinase',
    name: 'EGFR Kinase Domain (T790M/L858R Double Mutant)',
    shortName: 'EGFR Kinase (T790M)',
    pdbId: '2JIT',
    organism: 'Homo sapiens (Human)',
    diseaseArea: 'Oncology (Non-Small Cell Lung Cancer)',
    resolution: '1.95 Å',
    description: 'Receptor tyrosine kinase frequently hyperactivated in lung adenocarcinomas. The T790M gatekeeper mutation sterically blocks 1st-generation reversible ATP-competitive inhibitors like Gefitinib.',
    bindingSiteDescription: 'ATP-binding cleft flanked by the N-lobe and C-lobe, featuring gatekeeper Met790, catalytic Lys745, Asp855 (DFG motif), and covalent nucleophile Cys797 on the kinase hinge loop.',
    sequenceFasta: '>2JIT_1|Chain A|Epidermal growth factor receptor\nGEAPNQALLRILKETEFKKIKVLGSGAFGTVYKGLWIPEGEKVKIPVAIKELREATSPKANKEILDEAYVMASVDNPHVCRLLGICLTSTVQLITQLMPFGCLLDYVREHKDNIGSQYLLNWCVQIAKGMNYLEDRRLVHRDLAARNVLVKTPQHVKITDFGLAKLLGAEEKEYHAEGGKVPIKWMALESILHRIYTHQSDVWSYGVTVWELMTFGSKPYDGIPASEISSILEKGERLPQPPICTIDVYMIMVKCWMIDADSRPKFRELIIEFSKMARDPQRYLVIQGDERMHLPSPTDSNFYRALM',
    defaultLigandId: 'osimertinib',
    keyResidues: [
      { id: 'res-cys797', name: 'CYS', number: 797, chain: 'A', role: 'catalytic', x: 2.5, y: -0.8, z: 1.5, charge: 0 },
      { id: 'res-met790', name: 'MET', number: 790, chain: 'A', role: 'gatekeeper', x: -1.2, y: 2.1, z: -1.1, charge: 0 },
      { id: 'res-lys745', name: 'LYS', number: 745, chain: 'A', role: 'binding_pocket', x: -2.8, y: 1.1, z: 1.9, charge: 1 },
      { id: 'res-asp855', name: 'ASP', number: 855, chain: 'A', role: 'binding_pocket', x: -1.7, y: -2.5, z: 0.8, charge: -1 },
      { id: 'res-leu718', name: 'LEU', number: 718, chain: 'A', role: 'hydrophobic_wall', x: 3.1, y: 2.2, z: -0.5, charge: 0 },
      { id: 'res-thr854', name: 'THR', number: 854, chain: 'A', role: 'binding_pocket', x: 0.5, y: -2.9, z: -1.4, charge: 0 },
    ]
  },
  {
    id: 'kras-g12c',
    name: 'KRAS G12C (GTPase Switch-II Allosteric Pocket)',
    shortName: 'KRAS G12C',
    pdbId: '6OIM',
    organism: 'Homo sapiens (Human)',
    diseaseArea: 'Oncology (Colorectal, NSCLC & Pancreatic Cancer)',
    resolution: '1.65 Å',
    description: 'Small GTPase oncogene mutated in over 20% of all human cancers. The G12C substitution provides a mutant cysteine targeted by covalent allosteric inhibitors in the inactive GDP-bound state.',
    bindingSiteDescription: 'Cryptic Switch-II pocket beneath the effector-binding loop, adjacent to mutant Cys12, His95, Tyr96, and Arg68.',
    sequenceFasta: '>6OIM_1|Chain A|GTPase KRas\nMTEYKLVVVGACGVGKSALTIQLIQNHFVDEYDPTIEDSYRKQVVIDGETCLLDILDTAGQEEYSAMRDQYMRTGEGFLCVFAINNTKSFEDIHHYREQIKRVKDSEDVPMVLVGNKCDLPSRTVDTKQAQDLARSYGIPFIETSAKTRQGVDDAFYTLVREIRKHKEKMSKDGKKKKKKSKTKCVIM',
    defaultLigandId: 'sotorasib',
    keyResidues: [
      { id: 'res-cys12', name: 'CYS', number: 12, chain: 'A', role: 'catalytic', x: 1.8, y: -1.5, z: 0.2, charge: 0 },
      { id: 'res-his95', name: 'HIS', number: 95, chain: 'A', role: 'binding_pocket', x: -2.1, y: 0.8, z: 1.6, charge: 1 },
      { id: 'res-tyr96', name: 'TYR', number: 96, chain: 'A', role: 'hydrophobic_wall', x: -1.5, y: 2.6, z: -1.0, charge: 0 },
      { id: 'res-arg68', name: 'ARG', number: 68, chain: 'A', role: 'binding_pocket', x: 2.9, y: 1.8, z: 1.1, charge: 1 },
      { id: 'res-gln99', name: 'GLN', number: 99, chain: 'A', role: 'binding_pocket', x: 0.4, y: 3.1, z: 0.5, charge: 0 },
    ]
  },
  {
    id: 'bace1-amyloid',
    name: "Beta-Secretase 1 (BACE-1 / Aβ42 Cleavage)",
    shortName: "BACE-1 (Alzheimer's)",
    pdbId: '2OHQ',
    organism: 'Homo sapiens (Human)',
    diseaseArea: "Neurodegenerative (Alzheimer's Disease)",
    resolution: '1.80 Å',
    description: 'Membrane-bound aspartic protease that initiates the generation of toxic amyloid-beta (Aβ) peptides from amyloid precursor protein (APP).',
    bindingSiteDescription: 'Long catalytic cleft covered by a flexible antiparallel beta-hairpin "flap" (residues 67-75) with catalytic aspartate dyad Asp32 and Asp228.',
    sequenceFasta: '>2OHQ_1|Chain A|Beta-secretase 1\nETDEEPEEPGRRGSFVEMVDNLRGKSGQGYYVEMTVGSPPQTLNILVDTGSSNFAVGAAPHPFLHRYYQRQLSSTYRDLRKGVYVPYTQGKWEGELGTDLVSIPHGPNVTVRANIAAITESDKFFINGSNWEGILGLAYAEIARPDDSLEPFFDSLVKQTHVPNLFSLQLCGAGFPLNQSEVLASVGGSMIIGGIDHSLYTGSLWYTPIRREWYYEVIIVRVEINGQDLKMDCKEYNYDKSIVDSGTTNLRLPKKVFEAAVKSIKAASSTEKFPDGFWLGEQLVCWQAGTTPWNIFPVISLYLMGEVTNQSFRITILPQQYLRPVEDVATSQDDCYKFAISQSSTGTVMGAVIMEGFYVVFDRARKRIGFAVSACHVHDEFRTAAVEGPFVTLDMEDCGYNIPQTDESTLMTIAYVMAAICALFMLPLCLMVCQWRCLRCLRQQHDDFADDISLLK',
    defaultLigandId: 'donepezil',
    keyResidues: [
      { id: 'res-asp32', name: 'ASP', number: 32, chain: 'A', role: 'catalytic', x: -1.6, y: -0.9, z: 0.3, charge: -1 },
      { id: 'res-asp228', name: 'ASP', number: 228, chain: 'A', role: 'catalytic', x: 1.5, y: -1.1, z: -0.4, charge: -1 },
      { id: 'res-tyr71', name: 'TYR', number: 71, chain: 'A', role: 'binding_pocket', x: 0.1, y: 2.7, z: 1.4, charge: 0 },
      { id: 'res-arg128', name: 'ARG', number: 128, chain: 'A', role: 'binding_pocket', x: 3.1, y: 0.8, z: -1.8, charge: 1 },
      { id: 'res-ile118', name: 'ILE', number: 118, chain: 'A', role: 'hydrophobic_wall', x: -2.9, y: 1.9, z: -1.2, charge: 0 },
    ]
  },
  {
    id: 'hiv-1-rt',
    name: 'HIV-1 Reverse Transcriptase (NNRTI Allosteric Pocket)',
    shortName: 'HIV-1 RT',
    pdbId: '1RTD',
    organism: 'Human immunodeficiency virus type 1',
    diseaseArea: 'Viral Infectious Disease (HIV/AIDS)',
    resolution: '2.20 Å',
    description: 'RNA-dependent DNA polymerase essential for reverse transcription of viral RNA into double-stranded DNA. Non-nucleoside reverse transcriptase inhibitors (NNRTIs) bind an allosteric pocket ~10 Å from the polymerase active site.',
    bindingSiteDescription: 'Hydrophobic pocket formed by Tyr181, Tyr188, Phe227, Trp229, and Lys103, inducing a hyperextended thumb conformation that inactivates catalysis.',
    sequenceFasta: '>1RTD_1|Chain A|Reverse transcriptase\nPISPIETVPVKLKPGMDGPKVKQWPLTEEKIKALVEICTEMEKEGKISKIGPENPYNTPVFAIKKKDSTKWRKLVDFRELNKRTQDFWEVQLGIPHPAGLKKKKSVTVLDVGDAYFSVPLDEDFRKYTAFTIPSINNETPGIRYQYNVLPQGWKGSPAIFQSSMTKILEPFRKQNPDIVIYQYMDDLYVGSDLEIGQHRTKIEELRQHLLRWGLTTPDKKHQKEPPFLWMGYELHPDKWTVQPIVLPEKDSWTVNDIQKLVGKLNWASQIYPGIKVRQLCKLLRGTKALTEVIPLTEEAELELAENREILKEPVHGVYYDPSKDLIAEIQKQGQGQWTYQIYQEPFKNLKTGKYARMRGAHTNDVKQLTEAVQKITTESIVIWGKTPKFKLPIQKETWETWWTEYWQATWIPEWEFVNTPPLVKLWYQLEKEPIVGAETFYVDGAANRETKLGKAGYVTNKGRQKVVTLTDTTNQKTELQAIYLALQDSGLEVNIVTDSQYALGIIQAQPDKSESELVNQIIEQLIKKEKVYLAWVPAHKGIGGNEQVDKLVSAGIRKVL',
    defaultLigandId: 'remdesivir',
    keyResidues: [
      { id: 'res-tyr181', name: 'TYR', number: 181, chain: 'A', role: 'hydrophobic_wall', x: -1.8, y: 1.4, z: -1.3, charge: 0 },
      { id: 'res-tyr188', name: 'TYR', number: 188, chain: 'A', role: 'hydrophobic_wall', x: 1.9, y: 1.7, z: 0.8, charge: 0 },
      { id: 'res-lys103', name: 'LYS', number: 103, chain: 'A', role: 'binding_pocket', x: -2.4, y: -1.5, z: 1.2, charge: 1 },
      { id: 'res-trp229', name: 'TRP', number: 229, chain: 'A', role: 'hydrophobic_wall', x: 0.8, y: -2.3, z: -1.1, charge: 0 },
      { id: 'res-glu138', name: 'GLU', number: 138, chain: 'A', role: 'binding_pocket', x: 2.7, y: -0.6, z: 2.1, charge: -1 },
    ]
  }
];

export const CANDIDATE_LIGANDS: LigandCandidate[] = [
  {
    id: 'nirmatrelvir',
    name: 'Nirmatrelvir',
    tradeName: 'Paxlovid (active compound)',
    smiles: 'CC(C)(C)C(NC(=O)C(F)(F)F)C(=O)N1CC2C(C1C(=O)NC(CC3CCNC3=O)C#N)C2(C)C',
    formula: 'C23H32F3N5O4',
    molecularWeight: 499.53,
    logP: 0.81,
    hBondDonors: 3,
    hBondAcceptors: 8,
    rotatableBonds: 6,
    tpsa: 124.6,
    description: 'Orally bioavailable SARS-CoV-2 main protease (Mpro) inhibitor engineered with a nitrile electrophilic warhead that forms a reversible covalent thioimidate adduct with catalytic Cys145.',
    mechanism: 'Reversible covalent inhibition via nitrile warhead nucleophilic attack by Cys145 thiolate.',
    structure3D: {
      atoms: [
        { id: 0, element: 'C', x: 0.0, y: 0.0, z: 0.0, label: 'C1' },
        { id: 1, element: 'C', x: 1.2, y: 0.6, z: 0.3, label: 'C2' },
        { id: 2, element: 'N', x: 2.3, y: -0.2, z: 0.2, label: 'N3' },
        { id: 3, element: 'C', x: 3.5, y: 0.4, z: 0.5, label: 'C4' },
        { id: 4, element: 'O', x: 3.6, y: 1.6, z: 0.8, label: 'O5' },
        { id: 5, element: 'C', x: 4.7, y: -0.5, z: 0.3, label: 'C6' },
        { id: 6, element: 'N', x: 4.5, y: -1.8, z: 0.9, label: 'N7' },
        { id: 7, element: 'C', x: 1.3, y: 2.0, z: -0.2, label: 'C8' },
        { id: 8, element: 'F', x: 0.2, y: 2.7, z: 0.1, label: 'F9' },
        { id: 9, element: 'F', x: 2.3, y: 2.8, z: 0.3, label: 'F10' },
        { id: 10, element: 'F', x: 1.5, y: 2.0, z: -1.5, label: 'F11' },
        { id: 11, element: 'C', x: -1.2, y: 0.8, z: 0.5, label: 'C12' },
        { id: 12, element: 'O', x: -1.1, y: 2.0, z: 0.3, label: 'O13' },
        { id: 13, element: 'N', x: -2.3, y: 0.1, z: 1.0, label: 'N14' },
        { id: 14, element: 'C', x: -3.5, y: 0.8, z: 1.4, label: 'C15' },
        { id: 15, element: 'C', x: -4.6, y: -0.1, z: 1.8, label: 'C16_nitrile' },
        { id: 16, element: 'N', x: -5.5, y: -0.8, z: 2.2, label: 'N17_nitrile' },
        { id: 17, element: 'C', x: 0.1, y: -1.4, z: -0.5, label: 'C18' },
        { id: 18, element: 'C', x: -0.9, y: -2.2, z: 0.2, label: 'C19' },
        { id: 19, element: 'N', x: -0.4, y: -3.4, z: 0.6, label: 'N20_lactam' },
        { id: 20, element: 'C', x: 0.9, y: -3.3, z: 0.3, label: 'C21' },
        { id: 21, element: 'O', x: 1.7, y: -4.2, z: 0.5, label: 'O22' },
      ],
      bonds: [
        { from: 0, to: 1, order: 1 },
        { from: 1, to: 2, order: 1 },
        { from: 2, to: 3, order: 1 },
        { from: 3, to: 4, order: 2 },
        { from: 3, to: 5, order: 1 },
        { from: 5, to: 6, order: 1 },
        { from: 1, to: 7, order: 1 },
        { from: 7, to: 8, order: 1 },
        { from: 7, to: 9, order: 1 },
        { from: 7, to: 10, order: 1 },
        { from: 0, to: 11, order: 1 },
        { from: 11, to: 12, order: 2 },
        { from: 11, to: 13, order: 1 },
        { from: 13, to: 14, order: 1 },
        { from: 14, to: 15, order: 1 },
        { from: 15, to: 16, order: 3 },
        { from: 0, to: 17, order: 1 },
        { from: 17, to: 18, order: 1 },
        { from: 18, to: 19, order: 1 },
        { from: 19, to: 20, order: 1 },
        { from: 20, to: 21, order: 2 },
        { from: 20, to: 17, order: 1 },
      ]
    },
    targetInteractions: {
      'sars-cov-2-mpro': [
        {
          id: 'int-1',
          donorElement: 'S (Cys145)',
          donorResidue: 'Cys145',
          acceptorElement: 'C (Nitrile)',
          acceptorAtom: 'C16_nitrile',
          distanceAngstroms: 1.84,
          energyKcalMol: -8.4,
          type: 'covalent_warhead',
          startCoord: [2.1, 1.2, 0.4],
          endCoord: [-4.6, -0.1, 1.8]
        },
        {
          id: 'int-2',
          donorElement: 'N (His41)',
          donorResidue: 'His41',
          acceptorElement: 'O (Carbonyl)',
          acceptorAtom: 'O5',
          distanceAngstroms: 2.15,
          energyKcalMol: -4.2,
          type: 'hydrogen_bond',
          startCoord: [-1.9, 1.8, -0.6],
          endCoord: [3.6, 1.6, 0.8]
        },
        {
          id: 'int-3',
          donorElement: 'N (Amide)',
          donorResidue: 'Glu166',
          acceptorElement: 'O (Lactam)',
          acceptorAtom: 'O22',
          distanceAngstroms: 2.68,
          energyKcalMol: -3.8,
          type: 'hydrogen_bond',
          startCoord: [3.4, -2.1, 1.1],
          endCoord: [1.7, -4.2, 0.5]
        },
        {
          id: 'int-4',
          donorElement: 'N (Backbone)',
          donorResidue: 'Gly143',
          acceptorElement: 'O (Carbonyl)',
          acceptorAtom: 'O13',
          distanceAngstroms: 2.82,
          energyKcalMol: -2.9,
          type: 'hydrogen_bond',
          startCoord: [1.1, 3.2, 0.9],
          endCoord: [-1.1, 2.0, 0.3]
        }
      ]
    }
  },
  {
    id: 'osimertinib',
    name: 'Osimertinib',
    tradeName: 'Tagrisso (AZD9291)',
    smiles: 'CN(C)CC=CC(=O)Nc1cc(Nc2ncccn2)c(OC)cc1Nc3nc4ccccc4n3C',
    formula: 'C28H33N7O2',
    molecularWeight: 499.61,
    logP: 3.10,
    hBondDonors: 1,
    hBondAcceptors: 7,
    rotatableBonds: 8,
    tpsa: 76.8,
    description: '3rd-generation, irreversible mutant-selective epidermal growth factor receptor (EGFR) TKI that targets T790M and sensitizing L858R mutations while sparing wild-type EGFR.',
    mechanism: 'Michael addition covalent bonding of acrylamide warhead with Cys797 thiolate at the ATP binding pocket edge.',
    structure3D: {
      atoms: [
        { id: 0, element: 'C', x: 0.0, y: 0.0, z: 0.0, label: 'C_aniline' },
        { id: 1, element: 'C', x: 1.3, y: 0.4, z: 0.2, label: 'C_ring' },
        { id: 2, element: 'C', x: 2.3, y: -0.5, z: 0.1, label: 'C_ring' },
        { id: 3, element: 'C', x: 2.0, y: -1.8, z: -0.2, label: 'C_ring' },
        { id: 4, element: 'C', x: 0.7, y: -2.2, z: -0.3, label: 'C_ring' },
        { id: 5, element: 'C', x: -0.3, y: -1.3, z: -0.2, label: 'C_ring' },
        { id: 6, element: 'N', x: 3.6, y: -0.1, z: 0.3, label: 'N_linker' },
        { id: 7, element: 'C', x: 4.8, y: -0.8, z: 0.1, label: 'C_pyrimidine' },
        { id: 8, element: 'N', x: 5.9, y: -0.1, z: 0.3, label: 'N_pyr' },
        { id: 9, element: 'C', x: 7.0, y: -0.7, z: 0.1, label: 'C_pyr' },
        { id: 10, element: 'N', x: 6.9, y: -2.0, z: -0.2, label: 'N_pyr' },
        { id: 11, element: 'C', x: 5.8, y: -2.6, z: -0.4, label: 'C_pyr' },
        { id: 12, element: 'C', x: 4.7, y: -2.1, z: -0.2, label: 'C_pyr' },
        { id: 13, element: 'N', x: -1.0, y: 0.9, z: 0.2, label: 'N_acrylamide' },
        { id: 14, element: 'C', x: -2.3, y: 0.6, z: 0.0, label: 'C_carbonyl' },
        { id: 15, element: 'O', x: -2.8, y: -0.5, z: -0.3, label: 'O_carbonyl' },
        { id: 16, element: 'C', x: -3.2, y: 1.8, z: 0.3, label: 'C_alpha' },
        { id: 17, element: 'C', x: -4.5, y: 1.6, z: 0.1, label: 'C_beta_warhead' },
        { id: 18, element: 'O', x: 0.4, y: -3.5, z: -0.6, label: 'O_methoxy' },
        { id: 19, element: 'C', x: 1.4, y: -4.4, z: -0.8, label: 'C_methyl' }
      ],
      bonds: [
        { from: 0, to: 1, order: 1.5 },
        { from: 1, to: 2, order: 1.5 },
        { from: 2, to: 3, order: 1.5 },
        { from: 3, to: 4, order: 1.5 },
        { from: 4, to: 5, order: 1.5 },
        { from: 5, to: 0, order: 1.5 },
        { from: 2, to: 6, order: 1 },
        { from: 6, to: 7, order: 1 },
        { from: 7, to: 8, order: 1.5 },
        { from: 8, to: 9, order: 1.5 },
        { from: 9, to: 10, order: 1.5 },
        { from: 10, to: 11, order: 1.5 },
        { from: 11, to: 12, order: 1.5 },
        { from: 12, to: 7, order: 1.5 },
        { from: 0, to: 13, order: 1 },
        { from: 13, to: 14, order: 1 },
        { from: 14, to: 15, order: 2 },
        { from: 14, to: 16, order: 1 },
        { from: 16, to: 17, order: 2 },
        { from: 4, to: 18, order: 1 },
        { from: 18, to: 19, order: 1 }
      ]
    },
    targetInteractions: {
      'egfr-kinase': [
        {
          id: 'int-egfr-1',
          donorElement: 'S (Cys797)',
          donorResidue: 'Cys797',
          acceptorElement: 'C (Acrylamide)',
          acceptorAtom: 'C_beta_warhead',
          distanceAngstroms: 1.92,
          energyKcalMol: -9.1,
          type: 'covalent_warhead',
          startCoord: [2.5, -0.8, 1.5],
          endCoord: [-4.5, 1.6, 0.1]
        },
        {
          id: 'int-egfr-2',
          donorElement: 'N (Met790 Hinge)',
          donorResidue: 'Met790',
          acceptorElement: 'N (Pyrimidine)',
          acceptorAtom: 'N_pyr',
          distanceAngstroms: 2.34,
          energyKcalMol: -4.5,
          type: 'hydrogen_bond',
          startCoord: [-1.2, 2.1, -1.1],
          endCoord: [5.9, -0.1, 0.3]
        },
        {
          id: 'int-egfr-3',
          donorElement: 'Lys745 Ammonium',
          donorResidue: 'Lys745',
          acceptorElement: 'O (Carbonyl)',
          acceptorAtom: 'O_carbonyl',
          distanceAngstroms: 2.76,
          energyKcalMol: -3.9,
          type: 'hydrogen_bond',
          startCoord: [-2.8, 1.1, 1.9],
          endCoord: [-2.8, -0.5, -0.3]
        }
      ]
    }
  },
  {
    id: 'sotorasib',
    name: 'Sotorasib',
    tradeName: 'Lumakras (AMG 510)',
    smiles: 'Cc1cc(F)c(N2CCN(C(=O)C=C)CC2)c(c1)c3c(O)nc(NC4CC4)nc3',
    formula: 'C30H32F2N6O2',
    molecularWeight: 560.59,
    logP: 2.85,
    hBondDonors: 1,
    hBondAcceptors: 7,
    rotatableBonds: 4,
    tpsa: 92.5,
    description: 'First-in-class small molecule that irreversibly binds to the mutant cysteine 12 of GDP-bound KRAS G12C, locking it in an inactive state and preventing oncogenic RAS signaling.',
    mechanism: 'Irreversible covalent crosslinking of acryloyl warhead to mutant Cys12 inside the Switch-II pocket.',
    structure3D: {
      atoms: [
        { id: 0, element: 'C', x: 0.0, y: 0.0, z: 0.0, label: 'C_pyr' },
        { id: 1, element: 'N', x: 1.1, y: 0.6, z: 0.2, label: 'N_pyr' },
        { id: 2, element: 'C', x: 2.2, y: -0.1, z: 0.0, label: 'C_pyr' },
        { id: 3, element: 'N', x: 2.3, y: -1.4, z: -0.3, label: 'N_pyr' },
        { id: 4, element: 'C', x: 1.2, y: -2.0, z: -0.4, label: 'C_pyr' },
        { id: 5, element: 'C', x: 0.0, y: -1.3, z: -0.3, label: 'C_pyr' },
        { id: 6, element: 'O', x: -1.1, y: -2.0, z: -0.5, label: 'O_hydroxy' },
        { id: 7, element: 'C', x: -1.3, y: 0.7, z: 0.3, label: 'C_aryl' },
        { id: 8, element: 'C', x: -2.5, y: 0.0, z: 0.2, label: 'C_aryl' },
        { id: 9, element: 'C', x: -3.7, y: 0.7, z: 0.5, label: 'C_aryl' },
        { id: 10, element: 'F', x: -4.8, y: 0.0, z: 0.4, label: 'F_subst' },
        { id: 11, element: 'N', x: -3.8, y: 2.0, z: 0.9, label: 'N_piperazine' },
        { id: 12, element: 'C', x: -5.0, y: 2.7, z: 1.2, label: 'C_carbonyl' },
        { id: 13, element: 'O', x: -6.1, y: 2.2, z: 1.1, label: 'O_carbonyl' },
        { id: 14, element: 'C', x: -4.9, y: 4.1, z: 1.7, label: 'C_warhead_a' },
        { id: 15, element: 'C', x: -6.0, y: 4.9, z: 2.0, label: 'C_warhead_b' }
      ],
      bonds: [
        { from: 0, to: 1, order: 1.5 },
        { from: 1, to: 2, order: 1.5 },
        { from: 2, to: 3, order: 1.5 },
        { from: 3, to: 4, order: 1.5 },
        { from: 4, to: 5, order: 1.5 },
        { from: 5, to: 0, order: 1.5 },
        { from: 5, to: 6, order: 1 },
        { from: 0, to: 7, order: 1 },
        { from: 7, to: 8, order: 1.5 },
        { from: 8, to: 9, order: 1.5 },
        { from: 9, to: 10, order: 1 },
        { from: 9, to: 11, order: 1 },
        { from: 11, to: 12, order: 1 },
        { from: 12, to: 13, order: 2 },
        { from: 12, to: 14, order: 1 },
        { from: 14, to: 15, order: 2 }
      ]
    },
    targetInteractions: {
      'kras-g12c': [
        {
          id: 'int-kras-1',
          donorElement: 'S (Cys12)',
          donorResidue: 'Cys12',
          acceptorElement: 'C (Acryloyl)',
          acceptorAtom: 'C_warhead_b',
          distanceAngstroms: 1.88,
          energyKcalMol: -9.6,
          type: 'covalent_warhead',
          startCoord: [1.8, -1.5, 0.2],
          endCoord: [-6.0, 4.9, 2.0]
        },
        {
          id: 'int-kras-2',
          donorElement: 'His95 Imidazole',
          donorResidue: 'His95',
          acceptorElement: 'O (Hydroxy)',
          acceptorAtom: 'O_hydroxy',
          distanceAngstroms: 2.45,
          energyKcalMol: -4.1,
          type: 'hydrogen_bond',
          startCoord: [-2.1, 0.8, 1.6],
          endCoord: [-1.1, -2.0, -0.5]
        },
        {
          id: 'int-kras-3',
          donorElement: 'Tyr96 Aromatic',
          donorResidue: 'Tyr96',
          acceptorElement: 'Aryl Ring',
          acceptorAtom: 'C_aryl',
          distanceAngstroms: 3.65,
          energyKcalMol: -3.2,
          type: 'pi_stacking',
          startCoord: [-1.5, 2.6, -1.0],
          endCoord: [-2.5, 0.0, 0.2]
        }
      ]
    }
  },
  {
    id: 'remdesivir',
    name: 'Remdesivir',
    tradeName: 'Veklury (GS-5734)',
    smiles: 'CCC(CC)COC(=O)C(C)NP(=O)(OCC1C(C(C(O1)(C#N)c2ccc3c(n2)ncnn3)O)O)Oc4ccccc4',
    formula: 'C27H35N6O8P',
    molecularWeight: 602.58,
    logP: 1.90,
    hBondDonors: 4,
    hBondAcceptors: 12,
    rotatableBonds: 14,
    tpsa: 168.2,
    description: 'Phosphoramidate prodrug nucleotide analog metabolized intracellularly into Remdesivir triphosphate, acting as a delayed chain-terminator of viral RNA-dependent polymerases.',
    mechanism: 'Competitive incorporation into nascent viral RNA chain inducing steric arrest at position i+3.',
    structure3D: {
      atoms: [
        { id: 0, element: 'P', x: 0.0, y: 0.0, z: 0.0, label: 'P_phosphor' },
        { id: 1, element: 'O', x: 0.2, y: 1.4, z: 0.6, label: 'O_double' },
        { id: 2, element: 'O', x: -1.3, y: -0.6, z: 0.5, label: 'O_ester' },
        { id: 3, element: 'N', x: 1.2, y: -0.9, z: 0.4, label: 'N_amide' },
        { id: 4, element: 'O', x: 0.2, y: 0.2, z: -1.6, label: 'O_ribose' },
        { id: 5, element: 'C', x: 0.7, y: 1.4, z: -2.2, label: 'C_ribose1' },
        { id: 6, element: 'C', x: 0.4, y: 1.2, z: -3.7, label: 'C_ribose2' },
        { id: 7, element: 'O', x: 1.4, y: 0.3, z: -4.3, label: 'O_hydroxyl' },
        { id: 8, element: 'C', x: -1.0, y: 0.7, z: -3.8, label: 'C_ribose3' },
        { id: 9, element: 'C', x: -1.4, y: 1.1, z: -2.3, label: 'C_ribose4' },
        { id: 10, element: 'C', x: -2.7, y: 1.8, z: -2.1, label: 'C_nitrile' },
        { id: 11, element: 'N', x: -3.8, y: 2.3, z: -1.9, label: 'N_nitrile' },
        { id: 12, element: 'C', x: 2.1, y: 1.8, z: -1.9, label: 'C_base' },
        { id: 13, element: 'N', x: 3.1, y: 1.0, z: -1.5, label: 'N_base' },
        { id: 14, element: 'C', x: 4.2, y: 1.7, z: -1.4, label: 'C_base' }
      ],
      bonds: [
        { from: 0, to: 1, order: 2 },
        { from: 0, to: 2, order: 1 },
        { from: 0, to: 3, order: 1 },
        { from: 0, to: 4, order: 1 },
        { from: 4, to: 5, order: 1 },
        { from: 5, to: 6, order: 1 },
        { from: 6, to: 7, order: 1 },
        { from: 6, to: 8, order: 1 },
        { from: 8, to: 9, order: 1 },
        { from: 9, to: 5, order: 1 },
        { from: 9, to: 10, order: 1 },
        { from: 10, to: 11, order: 3 },
        { from: 5, to: 12, order: 1 },
        { from: 12, to: 13, order: 1.5 },
        { from: 13, to: 14, order: 1.5 }
      ]
    },
    targetInteractions: {
      'hiv-1-rt': [
        {
          id: 'int-hiv-1',
          donorElement: 'Tyr181 Aromatic',
          donorResidue: 'Tyr181',
          acceptorElement: 'Adenine Base',
          acceptorAtom: 'C_base',
          distanceAngstroms: 3.42,
          energyKcalMol: -3.8,
          type: 'pi_stacking',
          startCoord: [-1.8, 1.4, -1.3],
          endCoord: [2.1, 1.8, -1.9]
        },
        {
          id: 'int-hiv-2',
          donorElement: 'Lys103 Ammonium',
          donorResidue: 'Lys103',
          acceptorElement: 'Phosphoryl Oxygen',
          acceptorAtom: 'O_double',
          distanceAngstroms: 2.18,
          energyKcalMol: -4.8,
          type: 'hydrogen_bond',
          startCoord: [-2.4, -1.5, 1.2],
          endCoord: [0.2, 1.4, 0.6]
        }
      ]
    }
  },
  {
    id: 'donepezil',
    name: 'Donepezil',
    tradeName: 'Aricept (E2020)',
    smiles: 'COc1cc2c(cc1OC)C(=O)C(CC3CCN(CC3)Cc4ccccc4)C2',
    formula: 'C24H29NO3',
    molecularWeight: 379.49,
    logP: 4.12,
    hBondDonors: 0,
    hBondAcceptors: 4,
    rotatableBonds: 6,
    tpsa: 38.8,
    description: "Centrally active, reversible non-competitive inhibitor of acetylcholinesterase and BACE-1 flap modulator explored for Alzheimer's symptomatic and disease-modifying treatment.",
    mechanism: 'Span binding of both catalytic and peripheral anionic sites (PAS) stabilizing inactive flap conformation.',
    structure3D: {
      atoms: [
        { id: 0, element: 'C', x: 0.0, y: 0.0, z: 0.0, label: 'C_indanone' },
        { id: 1, element: 'C', x: 1.4, y: 0.2, z: 0.1, label: 'C_ring' },
        { id: 2, element: 'C', x: 2.1, y: -0.9, z: 0.0, label: 'C_ring' },
        { id: 3, element: 'C', x: 1.5, y: -2.2, z: -0.2, label: 'C_ring' },
        { id: 4, element: 'C', x: 0.1, y: -2.3, z: -0.3, label: 'C_ring' },
        { id: 5, element: 'C', x: -0.6, y: -1.2, z: -0.2, label: 'C_ring' },
        { id: 6, element: 'O', x: 3.4, y: -0.9, z: 0.1, label: 'O_methoxy1' },
        { id: 7, element: 'O', x: 2.2, y: -3.3, z: -0.3, label: 'O_methoxy2' },
        { id: 8, element: 'C', x: -2.1, y: -1.1, z: -0.2, label: 'C_indanone_c' },
        { id: 9, element: 'O', x: -2.9, y: -2.0, z: -0.4, label: 'O_carbonyl' },
        { id: 10, element: 'C', x: -2.4, y: 0.4, z: 0.1, label: 'C_piper_link' },
        { id: 11, element: 'C', x: -3.8, y: 0.8, z: 0.3, label: 'C_piperidine' },
        { id: 12, element: 'N', x: -4.8, y: -0.2, z: 0.1, label: 'N_piperidine' },
        { id: 13, element: 'C', x: -6.2, y: 0.2, z: 0.3, label: 'C_benzyl' },
        { id: 14, element: 'C', x: -7.2, y: -0.8, z: 0.1, label: 'C_phenyl' }
      ],
      bonds: [
        { from: 0, to: 1, order: 1.5 },
        { from: 1, to: 2, order: 1.5 },
        { from: 2, to: 3, order: 1.5 },
        { from: 3, to: 4, order: 1.5 },
        { from: 4, to: 5, order: 1.5 },
        { from: 5, to: 0, order: 1.5 },
        { from: 2, to: 6, order: 1 },
        { from: 3, to: 7, order: 1 },
        { from: 5, to: 8, order: 1 },
        { from: 8, to: 9, order: 2 },
        { from: 8, to: 10, order: 1 },
        { from: 10, to: 11, order: 1 },
        { from: 11, to: 12, order: 1 },
        { from: 12, to: 13, order: 1 },
        { from: 13, to: 14, order: 1 }
      ]
    },
    targetInteractions: {
      'bace1-amyloid': [
        {
          id: 'int-bace-1',
          donorElement: 'Piperidine N+ (Charged)',
          donorResidue: 'Asp32 / Asp228 Dyad',
          acceptorElement: 'Asp32 Carboxylate',
          acceptorAtom: 'N_piperidine',
          distanceAngstroms: 2.74,
          energyKcalMol: -5.4,
          type: 'hydrogen_bond',
          startCoord: [-1.6, -0.9, 0.3],
          endCoord: [-4.8, -0.2, 0.1]
        },
        {
          id: 'int-bace-2',
          donorElement: 'Tyr71 Flap',
          donorResidue: 'Tyr71',
          acceptorElement: 'Indanone Carbonyl',
          acceptorAtom: 'O_carbonyl',
          distanceAngstroms: 2.89,
          energyKcalMol: -3.6,
          type: 'hydrogen_bond',
          startCoord: [0.1, 2.7, 1.4],
          endCoord: [-2.9, -2.0, -0.4]
        }
      ]
    }
  }
];

// Helper to calculate Lipinski Rule of 5 violations
export function evaluateLipinski(ligand: {
  molecularWeight: number;
  logP: number;
  hBondDonors: number;
  hBondAcceptors: number;
}): { compliant: boolean; violations: string[] } {
  const violations: string[] = [];
  if (ligand.molecularWeight > 500) {
    violations.push(`Molecular Weight (${ligand.molecularWeight.toFixed(1)} > 500 Da)`);
  }
  if (ligand.logP > 5) {
    violations.push(`LogP (${ligand.logP.toFixed(2)} > 5.0)`);
  }
  if (ligand.hBondDonors > 5) {
    violations.push(`H-Bond Donors (${ligand.hBondDonors} > 5)`);
  }
  if (ligand.hBondAcceptors > 10) {
    violations.push(`H-Bond Acceptors (${ligand.hBondAcceptors} > 10)`);
  }
  return {
    compliant: violations.length <= 1, // Traditional Lipinski allows at most 1 violation
    violations
  };
}
