import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  TargetProtein,
  LigandCandidate,
  QuantumSimulationConfig,
  DockingSimulationResult,
  GeminiDockingAnalysis
} from './types/docking';
import {
  TARGET_PROTEINS,
  CANDIDATE_LIGANDS
} from './data/targetsAndLigands';
import { runQuantumDockingSimulation } from './services/quantumEngine';
import { Navbar } from './components/Navbar';
import { TargetSelector } from './components/TargetSelector';
import { LigandSelector } from './components/LigandSelector';
import { QuantumControlPanel } from './components/QuantumControlPanel';
import { MolecularViewer3D } from './components/MolecularViewer3D';
import { Pharmacophore2D } from './components/Pharmacophore2D';
import { ConvergenceChart } from './components/ConvergenceChart';
import { ComparisonMetrics } from './components/ComparisonMetrics';
import { GeminiAnalyst } from './components/GeminiAnalyst';
import { TheoryDocsModal } from './components/TheoryDocsModal';
import {
  Atom,
  Dna,
  Zap,
  Sparkles,
  Download,
  Share2,
  Check,
  Eye,
  TrendingDown,
  Gauge,
  Layers,
  ArrowRight
} from 'lucide-react';

export default function App() {
  // Navigation step
  const [activeStep, setActiveStep] = useState<number>(3); // Default on 3 (Quantum VQE) for instant interactivity!
  const [theoryDocsOpen, setTheoryDocsOpen] = useState<boolean>(false);
  const [isCopiedReport, setIsCopiedReport] = useState<boolean>(false);

  // Targets & Ligands state (supports custom additions)
  const [targetsList, setTargetsList] = useState<TargetProtein[]>(TARGET_PROTEINS);
  const [ligandsList, setLigandsList] = useState<LigandCandidate[]>(CANDIDATE_LIGANDS);

  const [selectedTarget, setSelectedTarget] = useState<TargetProtein>(TARGET_PROTEINS[0]);
  const [selectedLigand, setSelectedLigand] = useState<LigandCandidate>(CANDIDATE_LIGANDS[0]);

  // Quantum Simulation Configuration
  const [quantumConfig, setQuantumConfig] = useState<QuantumSimulationConfig>({
    qubits: 8,
    ansatzDepth: 3,
    ansatz: 'hardware_efficient',
    optimizer: 'COBYLA',
    maxIterations: 40,
    noiseLevel: 0.01,
    noiseMitigation: 'zne',
    shots: 4096
  });

  // Simulation execution state
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulationProgress, setSimulationProgress] = useState<number>(100);
  const [simulationResult, setSimulationResult] = useState<DockingSimulationResult>(() =>
    runQuantumDockingSimulation(TARGET_PROTEINS[0], CANDIDATE_LIGANDS[0], {
      qubits: 8,
      ansatzDepth: 3,
      ansatz: 'hardware_efficient',
      optimizer: 'COBYLA',
      maxIterations: 40,
      noiseLevel: 0.01,
      noiseMitigation: 'zne',
      shots: 4096
    })
  );

  // Visualizer tabs in Step 3
  const [activeVisualTab, setActiveVisualTab] = useState<'3d' | '2d' | 'chart' | 'benchmark'>('3d');

  // Gemini AI Analysis state
  const [geminiAnalysis, setGeminiAnalysis] = useState<GeminiDockingAnalysis | null>(null);
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState<boolean>(false);

  // Run simulation with progressive animation
  const handleRunSimulation = useCallback(() => {
    setIsSimulating(true);
    setSimulationProgress(0);

    const interval = setInterval(() => {
      setSimulationProgress((prev) => {
        if (prev >= 95) {
          clearInterval(interval);
          return 95;
        }
        return prev + 15;
      });
    }, 90);

    setTimeout(() => {
      clearInterval(interval);
      const result = runQuantumDockingSimulation(selectedTarget, selectedLigand, quantumConfig);
      setSimulationResult(result);
      setSimulationProgress(100);
      setIsSimulating(false);
      // Invalidate old analysis when simulation changes so user is encouraged to re-analyze
      setGeminiAnalysis(null);
    }, 700);
  }, [selectedTarget, selectedLigand, quantumConfig]);

  // Quick Preset Selection
  const handleSelectPreset = (targetId: string, ligandId?: string) => {
    const tgt = targetsList.find((t) => t.id === targetId) || targetsList[0];
    const ligId = ligandId || tgt.defaultLigandId;
    const lig = ligandsList.find((l) => l.id === ligId) || ligandsList[0];

    setSelectedTarget(tgt);
    setSelectedLigand(lig);
    setGeminiAnalysis(null);

    const result = runQuantumDockingSimulation(tgt, lig, quantumConfig);
    setSimulationResult(result);
  };

  // Reset all to default state
  const handleReset = () => {
    setSelectedTarget(TARGET_PROTEINS[0]);
    setSelectedLigand(CANDIDATE_LIGANDS[0]);
    setQuantumConfig({
      qubits: 8,
      ansatzDepth: 3,
      ansatz: 'hardware_efficient',
      optimizer: 'COBYLA',
      maxIterations: 40,
      noiseLevel: 0.01,
      noiseMitigation: 'zne',
      shots: 4096
    });
    const result = runQuantumDockingSimulation(TARGET_PROTEINS[0], CANDIDATE_LIGANDS[0], {
      qubits: 8,
      ansatzDepth: 3,
      ansatz: 'hardware_efficient',
      optimizer: 'COBYLA',
      maxIterations: 40,
      noiseLevel: 0.01,
      noiseMitigation: 'zne',
      shots: 4096
    });
    setSimulationResult(result);
    setGeminiAnalysis(null);
    setActiveStep(1);
  };

  // Run Gemini Analysis
  const handleRunGeminiAnalysis = async () => {
    setIsLoadingAnalysis(true);
    try {
      const res = await fetch('/api/gemini/analyze-docking', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          target: selectedTarget,
          ligand: selectedLigand,
          simulationResult
        })
      });
      const data = await res.json();
      if (data.analysis) {
        setGeminiAnalysis(data.analysis);
      }
    } catch (err) {
      console.error('Failed to run Gemini analysis:', err);
    } finally {
      setIsLoadingAnalysis(false);
    }
  };

  // Export Report as JSON
  const handleExportJson = () => {
    const reportData = {
      project: 'QuantumDock Screening Report',
      timestamp: new Date().toISOString(),
      target: selectedTarget,
      ligand: selectedLigand,
      quantumConfig,
      simulationResult,
      aiAnalysis: geminiAnalysis
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `QuantumDock_${selectedTarget.pdbId}_${selectedLigand.name}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Copy Summary to Clipboard
  const handleCopySummary = () => {
    const summaryText = `[QuantumDock Screening Summary]
Target: ${selectedTarget.name} (PDB: ${selectedTarget.pdbId})
Ligand: ${selectedLigand.name} (MW: ${selectedLigand.molecularWeight} Da, LogP: ${selectedLigand.logP})
VQE Ground State Energy: ${simulationResult.vqeGroundStateEnergy} kcal/mol
Classical MM-GBSA Energy: ${simulationResult.classicalBindingEnergy} kcal/mol
Electronic Correlation (ΔE_corr): ${simulationResult.electronicCorrelationEnergy} kcal/mol
Predicted Kd: ${simulationResult.predictedKdQuantum} ${simulationResult.kdUnit} (${simulationResult.bindingAffinityClassification})
Qubits: ${simulationResult.activeQubitsUsed} | Circuit Depth: ${quantumConfig.ansatzDepth} | Fidelity: ${(simulationResult.quantumStateFidelity * 100).toFixed(2)}%
Generated via QuantumDock AI Studio`;

    navigator.clipboard.writeText(summaryText);
    setIsCopiedReport(true);
    setTimeout(() => setIsCopiedReport(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#070B14] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Navigation */}
      <Navbar
        activeStep={activeStep}
        setActiveStep={setActiveStep}
        onSelectPreset={handleSelectPreset}
        onReset={handleReset}
        onOpenDocs={() => setTheoryDocsOpen(true)}
        isSimulating={isSimulating}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Step 1: Target Protein Selection */}
        {activeStep === 1 && (
          <TargetSelector
            selectedTarget={selectedTarget}
            onSelectTarget={(tgt) => {
              setSelectedTarget(tgt);
              // auto-select corresponding default ligand
              const defLig = ligandsList.find((l) => l.id === tgt.defaultLigandId);
              if (defLig) setSelectedLigand(defLig);
              const result = runQuantumDockingSimulation(tgt, defLig || selectedLigand, quantumConfig);
              setSimulationResult(result);
            }}
            onProceed={() => setActiveStep(2)}
            onAddCustomTarget={(newTgt) => setTargetsList((prev) => [newTgt, ...prev])}
          />
        )}

        {/* Step 2: Ligand Candidate Selection */}
        {activeStep === 2 && (
          <LigandSelector
            selectedLigand={selectedLigand}
            selectedTarget={selectedTarget}
            onSelectLigand={(lig) => {
              setSelectedLigand(lig);
              const result = runQuantumDockingSimulation(selectedTarget, lig, quantumConfig);
              setSimulationResult(result);
            }}
            onProceed={() => setActiveStep(3)}
            onBack={() => setActiveStep(1)}
            onAddCustomLigand={(newLig) => setLigandsList((prev) => [newLig, ...prev])}
          />
        )}

        {/* Step 3: Quantum VQE Docking Studio & Real-time Visualizer */}
        {activeStep === 3 && (
          <div className="space-y-6">
            {/* Header info badge bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-gradient-to-r from-slate-900/90 via-slate-900/80 to-cyan-950/40 border border-slate-800 shadow-xl">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-white font-bold text-base">
                      {selectedLigand.name}
                    </span>
                    <span className="text-slate-500 font-mono text-xs">docking into</span>
                    <span className="text-cyan-300 font-semibold text-sm">
                      {selectedTarget.shortName}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      PDB: {selectedTarget.pdbId}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    VQE Ground State: <span className="text-emerald-400 font-mono font-bold">{simulationResult.vqeGroundStateEnergy} kcal/mol</span> • Dissociation Constant: <span className="text-cyan-300 font-mono font-bold">{simulationResult.predictedKdQuantum} {simulationResult.kdUnit}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopySummary}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors border border-slate-700"
                  title="Copy Summary to Clipboard"
                >
                  {isCopiedReport ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
                  <span>{isCopiedReport ? 'Copied' : 'Share'}</span>
                </button>
                <button
                  onClick={handleExportJson}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors border border-slate-700"
                  title="Download JSON Report"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export JSON</span>
                </button>
                <button
                  onClick={() => {
                    setActiveStep(4);
                    if (!geminiAnalysis) handleRunGeminiAnalysis();
                  }}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-gradient-to-r from-purple-400 to-cyan-400 hover:from-purple-300 hover:to-cyan-300 rounded-lg transition-all shadow-md"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>AI Analysis</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Split Grid: Left Side Controls & Metrics | Right Side Visualizer & Curves */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Quantum Controls (5 cols) */}
              <div className="lg:col-span-5 space-y-6">
                <QuantumControlPanel
                  config={quantumConfig}
                  onChangeConfig={(cfg) => {
                    setQuantumConfig(cfg);
                    // auto re-evaluate on parameter change
                    const res = runQuantumDockingSimulation(selectedTarget, selectedLigand, cfg);
                    setSimulationResult(res);
                  }}
                  onRunSimulation={handleRunSimulation}
                  isSimulating={isSimulating}
                  simulationProgress={simulationProgress}
                />

                {/* Quick Target / Molecule Switcher */}
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs space-y-2.5">
                  <span className="text-slate-400 font-semibold block text-[11px] uppercase tracking-wider font-mono">
                    Active Screening Pair
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setActiveStep(1)}
                      className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800/80 border border-slate-800 text-left transition-colors"
                    >
                      <span className="text-[10px] text-cyan-400 block font-mono">TARGET</span>
                      <span className="text-white font-bold truncate block">{selectedTarget.shortName}</span>
                    </button>
                    <button
                      onClick={() => setActiveStep(2)}
                      className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800/80 border border-slate-800 text-left transition-colors"
                    >
                      <span className="text-[10px] text-emerald-400 block font-mono">LIGAND</span>
                      <span className="text-white font-bold truncate block">{selectedLigand.name}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column: Visualizer & Analysis Tabs (7 cols) */}
              <div className="lg:col-span-7 space-y-4">
                {/* Visualizer Mode Tabs */}
                <div className="flex items-center justify-between bg-slate-900/80 p-1.5 rounded-xl border border-slate-800">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => setActiveVisualTab('3d')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        activeVisualTab === '3d'
                          ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>3D Molecular Pocket</span>
                    </button>

                    <button
                      onClick={() => setActiveVisualTab('2d')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        activeVisualTab === '2d'
                          ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Layers className="w-3.5 h-3.5" />
                      <span>2D Pharmacophore</span>
                    </button>

                    <button
                      onClick={() => setActiveVisualTab('chart')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        activeVisualTab === 'chart'
                          ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <TrendingDown className="w-3.5 h-3.5" />
                      <span>VQE Convergence</span>
                    </button>

                    <button
                      onClick={() => setActiveVisualTab('benchmark')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        activeVisualTab === 'benchmark'
                          ? 'bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30 shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Gauge className="w-3.5 h-3.5" />
                      <span>Classical vs Quantum</span>
                    </button>
                  </div>
                </div>

                {/* Tab Views */}
                {activeVisualTab === '3d' && (
                  <MolecularViewer3D
                    target={selectedTarget}
                    ligand={selectedLigand}
                    activeInteractions={simulationResult.activeHydrogenBonds}
                  />
                )}

                {activeVisualTab === '2d' && (
                  <Pharmacophore2D
                    target={selectedTarget}
                    ligand={selectedLigand}
                    interactions={simulationResult.activeHydrogenBonds}
                  />
                )}

                {activeVisualTab === 'chart' && (
                  <ConvergenceChart simulationResult={simulationResult} />
                )}

                {activeVisualTab === 'benchmark' && (
                  <ComparisonMetrics result={simulationResult} />
                )}
              </div>
            </div>

            {/* Convergence Chart also mirrored underneath if on 3D view for continuous monitoring */}
            {activeVisualTab === '3d' && (
              <div className="pt-2">
                <ConvergenceChart simulationResult={simulationResult} />
              </div>
            )}
          </div>
        )}

        {/* Step 4: Gemini AI Biomolecule Analyst */}
        {activeStep === 4 && (
          <GeminiAnalyst
            target={selectedTarget}
            ligand={selectedLigand}
            simulationResult={simulationResult}
            analysis={geminiAnalysis}
            isLoadingAnalysis={isLoadingAnalysis}
            onRunAnalysis={handleRunGeminiAnalysis}
          />
        )}
      </main>

      {/* Scientific Theory & Docs Modal */}
      <TheoryDocsModal
        isOpen={theoryDocsOpen}
        onClose={() => setTheoryDocsOpen(false)}
      />

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-800/80 bg-[#060911] px-6 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Atom className="w-4 h-4 text-cyan-400" />
            <span className="font-semibold text-slate-300">QuantumDock Studio</span>
            <span>— Variational Quantum Eigensolver & Gemini AI Screening</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] font-mono">
            <span>Jordan-Wigner Mapping</span>
            <span>•</span>
            <span>NISQ Depolarizing Noise Mitigation</span>
            <span>•</span>
            <span>MM-GBSA Comparison</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
