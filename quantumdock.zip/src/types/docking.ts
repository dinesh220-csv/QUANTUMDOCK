export interface AminoAcidResidue {
  id: string;
  name: string;
  number: number;
  chain: string;
  role: 'catalytic' | 'gatekeeper' | 'binding_pocket' | 'hydrophobic_wall';
  x: number;
  y: number;
  z: number;
  charge: number; // e.g. -1 for Asp, +1 for Lys/Arg, 0 neutral
}

export interface TargetProtein {
  id: string;
  name: string;
  shortName: string;
  pdbId: string;
  organism: string;
  diseaseArea: string;
  resolution: string;
  description: string;
  bindingSiteDescription: string;
  sequenceFasta: string;
  keyResidues: AminoAcidResidue[];
  defaultLigandId: string;
}

export interface Atom3D {
  id: number;
  element: 'C' | 'N' | 'O' | 'S' | 'F' | 'Cl' | 'H' | 'P';
  x: number;
  y: number;
  z: number;
  charge?: number;
  label?: string;
}

export interface Bond3D {
  from: number;
  to: number;
  order: 1 | 2 | 3 | 1.5; // 1.5 for aromatic
}

export interface HydrogenBondInteraction {
  id: string;
  donorElement: string;
  donorResidue: string;
  acceptorElement: string;
  acceptorAtom: string;
  distanceAngstroms: number;
  energyKcalMol: number;
  type: 'hydrogen_bond' | 'pi_stacking' | 'covalent_warhead' | 'hydrophobic';
  startCoord: [number, number, number];
  endCoord: [number, number, number];
}

export interface LigandCandidate {
  id: string;
  name: string;
  tradeName?: string;
  smiles: string;
  formula: string;
  molecularWeight: number;
  logP: number;
  hBondDonors: number;
  hBondAcceptors: number;
  rotatableBonds: number;
  tpsa: number; // Topological Polar Surface Area (Å²)
  description: string;
  mechanism: string;
  structure3D: {
    atoms: Atom3D[];
    bonds: Bond3D[];
  };
  targetInteractions: Record<string, HydrogenBondInteraction[]>;
}

export type QuantumOptimizer = 'COBYLA' | 'SPSA' | 'Adam' | 'SLSQP';
export type NoiseMitigationMethod = 'none' | 'zne' | 'rem' | 'cdr';
export type QuantumAnsatz = 'hardware_efficient' | 'uccsd' | 'ryrz_cx';

export interface QuantumSimulationConfig {
  qubits: number; // 4 to 16
  ansatzDepth: number; // 1 to 8
  ansatz: QuantumAnsatz;
  optimizer: QuantumOptimizer;
  maxIterations: number;
  noiseLevel: number; // 0.000 to 0.050 (e.g. 0% to 5% depolarizing error)
  noiseMitigation: NoiseMitigationMethod;
  shots: number; // 1024, 4096, 8192, or 0 for statevector
}

export interface IterationPoint {
  iteration: number;
  vqeEnergy: number;
  classicalEnergy: number;
  variance: number;
  correlationContribution: number;
}

export interface DockingSimulationResult {
  targetId: string;
  ligandId: string;
  config: QuantumSimulationConfig;
  
  // Quantum metrics
  vqeGroundStateEnergy: number; // kcal/mol
  vqeEnergyHartree: number;
  hartreeFockReferenceEnergy: number; // kcal/mol
  electronicCorrelationEnergy: number; // kcal/mol
  quantumStateFidelity: number; // e.g. 0.994 (99.4%)
  cnotGateCount: number;
  activeQubitsUsed: number;
  quantumRuntimeSec: number;
  
  // Classical force field comparison (MM-GBSA)
  classicalBindingEnergy: number; // kcal/mol
  classicalVdwEnergy: number; // kcal/mol
  classicalCoulombEnergy: number; // kcal/mol
  classicalSolvationPenalty: number; // kcal/mol
  classicalRuntimeSec: number;
  
  // Biophysical affinity
  predictedKdQuantum: number; // in nM or µM
  predictedKdClassical: number;
  kdUnit: 'nM' | 'µM' | 'pM';
  bindingAffinityClassification: 'Sub-nanomolar' | 'Nanomolar' | 'Micromolar' | 'Weak';
  
  // Convergence trajectory
  convergenceData: IterationPoint[];
  chemicalAccuracyThreshold: number; // ±1.0 kcal/mol around exact ground state
  iterationsToConverge: number;
  
  // Structural fit
  rmsdFromCrystal: number; // Ångströms
  activeHydrogenBonds: HydrogenBondInteraction[];
}

export interface GeminiDockingAnalysis {
  summary: string;
  quantumInsight: {
    correlationImpact: string;
    electronicOverlaps: string;
    accuracyAdvantage: string;
  };
  drugLikeness: {
    lipinskiCompliance: boolean;
    lipinskiViolations: string[];
    bioavailabilityScore: number; // 0 to 100
    bloodBrainBarrier: 'High' | 'Moderate' | 'Low';
    admetAssessment: string;
  };
  toxicityAndRisks: {
    hergCardiotoxicity: 'Low' | 'Moderate' | 'High';
    hepatotoxicityRisk: 'Low' | 'Moderate' | 'High';
    cypInteractions: string;
  };
  leadOptimizations: Array<{
    targetSite: string;
    modification: string;
    rationale: string;
    predictedAffinityGain: string;
  }>;
  experimentalValidation: {
    recommendedAssays: string[];
    crystallographyConditions: string;
  };
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'gemini';
  text: string;
  timestamp: string;
}
