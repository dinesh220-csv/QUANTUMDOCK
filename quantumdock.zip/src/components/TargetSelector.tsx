import React, { useState } from 'react';
import { TargetProtein } from '../types/docking';
import {
  TARGET_PROTEINS
} from '../data/targetsAndLigands';
import {
  Dna,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  PlusCircle,
  CheckCircle2,
  ShieldAlert,
  Sparkles,
  Layers,
  ArrowRight
} from 'lucide-react';

interface TargetSelectorProps {
  selectedTarget: TargetProtein;
  onSelectTarget: (target: TargetProtein) => void;
  onProceed: () => void;
  onAddCustomTarget: (target: TargetProtein) => void;
}

export const TargetSelector: React.FC<TargetSelectorProps> = ({
  selectedTarget,
  onSelectTarget,
  onProceed,
  onAddCustomTarget
}) => {
  const [expandedFastaId, setExpandedFastaId] = useState<string | null>(null);
  const [showCustomModal, setShowCustomModal] = useState(false);

  // Custom target form state
  const [customName, setCustomName] = useState('');
  const [customPdb, setCustomPdb] = useState('');
  const [customDisease, setCustomDisease] = useState('');
  const [customDesc, setCustomDesc] = useState('');
  const [customFasta, setCustomFasta] = useState('');

  const handleCreateCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;

    const newTarget: TargetProtein = {
      id: `custom-${Date.now()}`,
      name: customName,
      shortName: customName.slice(0, 18),
      pdbId: customPdb.trim().toUpperCase() || 'CUSTOM',
      organism: 'Homo sapiens / Synthetic Model',
      diseaseArea: customDisease.trim() || 'Biomedical Target',
      resolution: '2.0 Å (Predicted)',
      description: customDesc.trim() || 'Custom user-specified macromolecular target.',
      bindingSiteDescription: 'User-specified binding pocket and coordinate field.',
      sequenceFasta: customFasta.trim() || `>${customName}\nMKLLVLGLALLALACAGQEAAGV`,
      defaultLigandId: 'nirmatrelvir',
      keyResidues: [
        { id: 'res-c1', name: 'CYS', number: 101, chain: 'A', role: 'catalytic', x: 1.5, y: 1.0, z: 0.2, charge: 0 },
        { id: 'res-h1', name: 'HIS', number: 102, chain: 'A', role: 'catalytic', x: -1.2, y: 1.5, z: -0.4, charge: 1 },
        { id: 'res-b1', name: 'GLU', number: 103, chain: 'A', role: 'binding_pocket', x: 2.8, y: -1.9, z: 0.8, charge: -1 }
      ]
    };

    onAddCustomTarget(newTarget);
    onSelectTarget(newTarget);
    setShowCustomModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-cyan-950/40 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 font-mono">
              Step 1 of 4
            </span>
            <span className="text-xs text-slate-400">Biological Target Formulation</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">
            Select Disease Protein Target
          </h2>
          <p className="text-sm text-slate-400 max-w-2xl mt-1">
            Choose a validated therapeutic target or define a custom protein receptor. The active site coordinates and key residues will be mapped into the quantum Hamiltonian active space.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowCustomModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-cyan-300 bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-600/40 rounded-xl transition-all shadow-[0_0_15px_rgba(6,182,212,0.15)]"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Custom Target / FASTA</span>
          </button>
          <button
            onClick={onProceed}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-teal-400 hover:from-cyan-300 hover:to-teal-300 rounded-xl transition-all shadow-[0_0_20px_rgba(6,182,212,0.35)]"
          >
            <span>Proceed to Ligand</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Target Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {TARGET_PROTEINS.map((target) => {
          const isSelected = selectedTarget.id === target.id;
          const isFastaExpanded = expandedFastaId === target.id;

          return (
            <div
              key={target.id}
              onClick={() => onSelectTarget(target)}
              className={`relative cursor-pointer rounded-2xl p-5 transition-all flex flex-col justify-between border ${
                isSelected
                  ? 'bg-gradient-to-b from-cyan-950/60 via-slate-900/90 to-slate-950 border-cyan-400 shadow-[0_0_25px_rgba(6,182,212,0.25)] ring-1 ring-cyan-400/50'
                  : 'bg-slate-900/70 hover:bg-slate-900/90 border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Active selection badge */}
              {isSelected && (
                <div className="absolute top-4 right-4 flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-cyan-500 text-slate-950 text-[10px] font-bold tracking-wider uppercase">
                  <CheckCircle2 className="w-3 h-3" />
                  Selected
                </div>
              )}

              <div>
                {/* PDB & Meta Row */}
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                    PDB: {target.pdbId}
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">
                    {target.resolution}
                  </span>
                  <a
                    href={`https://www.rcsb.org/structure/${target.pdbId}`}
                    target="_blank"
                    rel="noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="text-slate-500 hover:text-cyan-400 p-0.5 transition-colors"
                    title="View on RCSB PDB"
                  >
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                {/* Protein Title */}
                <h3 className="text-base font-bold text-white leading-snug">
                  {target.name}
                </h3>
                <p className="text-xs text-emerald-400 font-medium mt-1">
                  {target.diseaseArea}
                </p>

                {/* Description */}
                <p className="text-xs text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                  {target.description}
                </p>

                {/* Pocket Residues */}
                <div className="mt-4 pt-3 border-t border-slate-800/80">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                    <span className="flex items-center gap-1 font-semibold text-slate-300">
                      <Layers className="w-3 h-3 text-cyan-400" />
                      Active Pocket Residues ({target.keyResidues.length}):
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {target.keyResidues.map((res) => {
                      let tagColor = 'bg-slate-800 text-slate-300 border-slate-700';
                      if (res.role === 'catalytic') {
                        tagColor = 'bg-rose-950/70 text-rose-300 border-rose-800/60 font-semibold';
                      } else if (res.role === 'gatekeeper') {
                        tagColor = 'bg-amber-950/70 text-amber-300 border-amber-800/60 font-semibold';
                      } else if (res.role === 'binding_pocket') {
                        tagColor = 'bg-cyan-950/70 text-cyan-300 border-cyan-800/60';
                      }
                      return (
                        <span
                          key={res.id}
                          className={`text-[10px] font-mono px-2 py-0.5 rounded border ${tagColor}`}
                          title={`Residue ${res.name}${res.number} (Role: ${res.role})`}
                        >
                          {res.name}{res.number}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* FASTA accordion */}
              <div className="mt-4 pt-3 border-t border-slate-800/60">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setExpandedFastaId(isFastaExpanded ? null : target.id);
                  }}
                  className="flex items-center justify-between w-full text-[11px] text-slate-400 hover:text-slate-200 transition-colors"
                >
                  <span className="font-mono flex items-center gap-1">
                    <Dna className="w-3 h-3 text-cyan-400" />
                    FASTA Sequence
                  </span>
                  {isFastaExpanded ? (
                    <ChevronUp className="w-3.5 h-3.5" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5" />
                  )}
                </button>
                {isFastaExpanded && (
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="mt-2 p-2 bg-slate-950 rounded-lg border border-slate-800 text-[10px] font-mono text-cyan-400/90 break-all max-h-32 overflow-y-auto leading-relaxed select-all"
                  >
                    {target.sequenceFasta}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Target Deep-Dive Banner */}
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="text-slate-300 font-medium">
              Currently Selected Target: <span className="text-white font-bold">{selectedTarget.name}</span>
            </div>
            <div className="text-slate-400 text-[11px]">
              Active site: {selectedTarget.bindingSiteDescription}
            </div>
          </div>
        </div>
        <button
          onClick={onProceed}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-all"
        >
          <span>Select Ligand</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Custom Target Modal */}
      {showCustomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-slate-900 border border-cyan-800/80 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Dna className="w-5 h-5 text-cyan-400" />
                Add Custom Protein Target
              </h3>
              <button
                onClick={() => setShowCustomModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateCustom} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Target Protein Name *
                </label>
                <input
                  type="text"
                  required
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="e.g., BRAF V600E Kinase Domain"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    PDB ID (Optional)
                  </label>
                  <input
                    type="text"
                    value={customPdb}
                    onChange={(e) => setCustomPdb(e.target.value)}
                    placeholder="e.g., 4MNE"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Disease Area
                  </label>
                  <input
                    type="text"
                    value={customDisease}
                    onChange={(e) => setCustomDisease(e.target.value)}
                    placeholder="e.g., Melanoma Oncology"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Biological Function / Mechanism
                </label>
                <textarea
                  rows={2}
                  value={customDesc}
                  onChange={(e) => setCustomDesc(e.target.value)}
                  placeholder="Briefly describe the target's role in the disease pathway..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  FASTA Amino Acid Sequence
                </label>
                <textarea
                  rows={3}
                  value={customFasta}
                  onChange={(e) => setCustomFasta(e.target.value)}
                  placeholder=">Target_ChainA&#10;MAALSGGGGGGAEPGQALFNG..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-cyan-300 placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono text-[11px]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCustomModal(false)}
                  className="px-3.5 py-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold"
                >
                  Create & Select Target
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
