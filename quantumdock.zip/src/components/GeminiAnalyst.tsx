import React, { useState } from 'react';
import {
  TargetProtein,
  LigandCandidate,
  DockingSimulationResult,
  GeminiDockingAnalysis,
  ChatMessage
} from '../types/docking';
import {
  Sparkles,
  Zap,
  ShieldAlert,
  ShieldCheck,
  HeartPulse,
  FlaskConical,
  MessageSquare,
  Send,
  RefreshCw,
  Lightbulb,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ExternalLink
} from 'lucide-react';

interface GeminiAnalystProps {
  target: TargetProtein;
  ligand: LigandCandidate;
  simulationResult: DockingSimulationResult;
  analysis: GeminiDockingAnalysis | null;
  isLoadingAnalysis: boolean;
  onRunAnalysis: () => void;
}

export const GeminiAnalyst: React.FC<GeminiAnalystProps> = ({
  target,
  ligand,
  simulationResult,
  analysis,
  isLoadingAnalysis,
  onRunAnalysis
}) => {
  // Chat state
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isSendingMessage, setIsSendingMessage] = useState(false);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isSendingMessage) return;

    const userText = inputMessage.trim();
    setInputMessage('');

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, newMsg]);
    setIsSendingMessage(true);

    try {
      const res = await fetch('/api/gemini/chat-docking', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userText,
          context: {
            target,
            ligand,
            simulationResult
          }
        })
      });
      const data = await res.json();
      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'gemini',
        text: data.reply || data.error || 'No analysis generated.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'gemini',
        text: `Error connecting to Gemini API: ${err.message}`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsSendingMessage(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Trigger Button */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-900/90 via-slate-900/80 to-purple-950/40 border border-slate-800 shadow-2xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-purple-500/10 text-purple-400 border border-purple-500/30 font-mono">
              Step 4 of 4
            </span>
            <span className="text-xs text-slate-400">Gemini AI Biomolecule Evaluation</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-purple-400" />
            AI Quantum-Biomolecular Analyst
          </h2>
          <p className="text-sm text-slate-400 max-w-2xl mt-1">
            Evaluates VQE binding energy, electronic correlation advantage, ADMET pharmacokinetics, and delivers actionable medicinal chemistry lead optimization strategies.
          </p>
        </div>

        <div>
          <button
            onClick={onRunAnalysis}
            disabled={isLoadingAnalysis}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-xl ${
              isLoadingAnalysis
                ? 'bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-700'
                : 'bg-gradient-to-r from-purple-500 via-indigo-500 to-cyan-400 hover:from-purple-400 hover:to-cyan-300 text-white shadow-[0_0_25px_rgba(168,85,247,0.4)] active:scale-[0.99]'
            }`}
          >
            {isLoadingAnalysis ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-purple-300" />
                <span>Generating AI Drug Screening Report...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>{analysis ? 'Re-Analyze with Gemini AI' : 'Analyze Binding Properties with Gemini'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Analysis Content or Initial Call-to-action */}
      {!analysis && !isLoadingAnalysis && (
        <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mx-auto shadow-inner">
            <Sparkles className="w-6 h-6 animate-pulse" />
          </div>
          <div className="max-w-md mx-auto space-y-2">
            <h3 className="text-base font-bold text-white">
              Ready for Gemini AI Scientific Assessment
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Click &quot;Analyze Binding Properties with Gemini&quot; above to synthesize the quantum VQE results ({simulationResult.vqeGroundStateEnergy} kcal/mol) with chemical structure parameters and ADMET drug-likeness rules.
            </p>
          </div>
          <button
            onClick={onRunAnalysis}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow-lg"
          >
            Run Gemini AI Analysis Now
          </button>
        </div>
      )}

      {/* Loading Skeleton */}
      {isLoadingAnalysis && (
        <div className="p-8 rounded-2xl bg-slate-900/80 border border-purple-900/40 space-y-4 text-center animate-pulse">
          <div className="w-10 h-10 border-3 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-sm font-semibold text-purple-300">
            Gemini is reasoning through multi-orbital quantum Hamiltonian and ADMET risk profile...
          </p>
          <p className="text-xs text-slate-500 font-mono">
            Evaluating VQE ground state: {simulationResult.vqeGroundStateEnergy} kcal/mol • Electronic correlation: {simulationResult.electronicCorrelationEnergy} kcal/mol
          </p>
        </div>
      )}

      {/* Results View */}
      {analysis && !isLoadingAnalysis && (
        <div className="space-y-6">
          {/* Executive Summary Card */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-purple-400 font-mono uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              Executive Scientific Summary
            </div>
            <p className="text-sm text-slate-200 leading-relaxed font-sans">
              {analysis.summary}
            </p>
          </div>

          {/* 2-Column: Quantum Insight & Drug-likeness ADMET */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Quantum Advantage Card */}
            <div className="p-5 rounded-2xl bg-slate-900/90 border border-cyan-900/60 shadow-xl space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 font-mono uppercase">
                <Zap className="w-4 h-4 text-cyan-400" />
                Quantum VQE Mechanics Insight
              </div>

              <div className="space-y-2.5 text-xs">
                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-slate-400 font-semibold block mb-1">
                    Electronic Correlation Impact:
                  </span>
                  <p className="text-slate-300 leading-relaxed">
                    {analysis.quantumInsight.correlationImpact}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-slate-400 font-semibold block mb-1">
                    Orbital Overlaps & Warhead Mechanics:
                  </span>
                  <p className="text-slate-300 leading-relaxed">
                    {analysis.quantumInsight.electronicOverlaps}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-slate-400 font-semibold block mb-1">
                    Accuracy Advantage over Classical:
                  </span>
                  <p className="text-slate-300 leading-relaxed">
                    {analysis.quantumInsight.accuracyAdvantage}
                  </p>
                </div>
              </div>
            </div>

            {/* ADMET & Drug-Likeness Card */}
            <div className="p-5 rounded-2xl bg-slate-900/90 border border-emerald-900/60 shadow-xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 font-mono uppercase">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Drug-Likeness & ADMET Scorecard
                </div>
                <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${
                  analysis.drugLikeness.lipinskiCompliance
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    : 'bg-amber-950 text-amber-400 border border-amber-800'
                }`}>
                  Lipinski {analysis.drugLikeness.lipinskiCompliance ? 'Compliant' : 'Warning'}
                </span>
              </div>

              {/* Bioavailability gauge */}
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1.5 text-xs">
                <div className="flex justify-between font-mono">
                  <span className="text-slate-400">Oral Bioavailability Score:</span>
                  <span className="text-emerald-400 font-bold">{analysis.drugLikeness.bioavailabilityScore}%</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-400 h-full transition-all"
                    style={{ width: `${analysis.drugLikeness.bioavailabilityScore}%` }}
                  />
                </div>
              </div>

              {/* BBB & Toxicity badges */}
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-slate-500 block text-[10px] uppercase">Blood-Brain Barrier</span>
                  <span className="text-white font-bold">{analysis.drugLikeness.bloodBrainBarrier}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-slate-500 block text-[10px] uppercase">hERG Cardiotoxicity</span>
                  <span className={`font-bold ${
                    analysis.toxicityAndRisks.hergCardiotoxicity === 'Low' ? 'text-emerald-400' : 'text-amber-400'
                  }`}>
                    {analysis.toxicityAndRisks.hergCardiotoxicity}
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs">
                <span className="text-slate-400 font-semibold block mb-1">
                  Pharmacokinetic & Metabolism Commentary:
                </span>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  {analysis.drugLikeness.admetAssessment}
                </p>
                <p className="text-slate-400 text-[10px] mt-1 font-mono">
                  CYP interactions: {analysis.toxicityAndRisks.cypInteractions}
                </p>
              </div>
            </div>
          </div>

          {/* Lead Optimization Strategies */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-white font-mono uppercase">
              <Lightbulb className="w-4 h-4 text-amber-400" />
              Medicinal Chemistry Lead Optimization Recommendations
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {analysis.leadOptimizations.map((opt, i) => (
                <div
                  key={i}
                  className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-cyan-400 font-semibold font-mono text-[11px]">
                      Site: {opt.targetSite}
                    </span>
                    <span className="text-emerald-400 font-bold font-mono text-[10px] px-1.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-800">
                      {opt.predictedAffinityGain}
                    </span>
                  </div>
                  <h4 className="text-white font-bold">
                    {opt.modification}
                  </h4>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    {opt.rationale}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Experimental Assays */}
          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div>
              <div className="text-white font-semibold flex items-center gap-1.5 mb-1">
                <FlaskConical className="w-4 h-4 text-cyan-400" />
                Recommended In Vitro Assay Protocol:
              </div>
              <ul className="text-slate-400 list-disc list-inside space-y-0.5 text-[11px]">
                {analysis.experimentalValidation.recommendedAssays.map((assay, idx) => (
                  <li key={idx}>{assay}</li>
                ))}
              </ul>
            </div>
            <div className="text-[11px] font-mono text-slate-400 bg-slate-950 p-2.5 rounded-lg border border-slate-800 max-w-xs">
              <span className="text-cyan-400 block font-semibold mb-0.5">X-Ray Crystallography:</span>
              {analysis.experimentalValidation.crystallographyConditions}
            </div>
          </div>

          {/* Interactive Chat with Gemini Analyst */}
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-purple-400" />
                Inquire with Gemini Biomolecule Analyst
              </h3>
              <span className="text-[10px] text-slate-500 font-mono">
                Ask hypothesis questions, bioisosteres, synthetic routes
              </span>
            </div>

            {/* Chat Messages Log */}
            {messages.length > 0 && (
              <div className="max-h-60 overflow-y-auto space-y-2.5 p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs">
                {messages.map((m) => (
                  <div
                    key={m.id}
                    className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-xl px-3 py-2 leading-relaxed ${
                        m.sender === 'user'
                          ? 'bg-purple-600 text-white rounded-br-none'
                          : 'bg-slate-800 text-slate-200 border border-slate-700 rounded-bl-none'
                      }`}
                    >
                      {m.text}
                    </div>
                    <span className="text-[9px] text-slate-500 mt-0.5 font-mono">
                      {m.sender === 'user' ? 'You' : 'Gemini AI'} • {m.timestamp}
                    </span>
                  </div>
                ))}
                {isSendingMessage && (
                  <div className="flex items-center gap-2 text-xs text-purple-300 font-mono p-2">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Gemini is generating response...</span>
                  </div>
                )}
              </div>
            )}

            {/* Chat Input Form */}
            <form onSubmit={handleSendMessage} className="flex gap-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Ask e.g.: 'How would adding a fluorine at C-3 affect permeability?' or 'Is there risk of covalent off-target binding?'"
                className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
              <button
                type="submit"
                disabled={!inputMessage.trim() || isSendingMessage}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 disabled:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
