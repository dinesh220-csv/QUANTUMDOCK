import React, { useState } from 'react';
import { DockingSimulationResult, IterationPoint } from '../types/docking';
import {
  TrendingDown,
  Activity,
  Zap,
  Clock,
  ShieldCheck,
  CheckCircle2,
  Sliders,
  Sparkles
} from 'lucide-react';

interface ConvergenceChartProps {
  simulationResult: DockingSimulationResult;
}

export const ConvergenceChart: React.FC<ConvergenceChartProps> = ({
  simulationResult
}) => {
  const [hoveredPoint, setHoveredPoint] = useState<IterationPoint | null>(null);

  const data = simulationResult.convergenceData;
  if (!data || data.length === 0) return null;

  // Chart Dimensions & Margins
  const width = 640;
  const height = 240;
  const padding = { top: 25, right: 30, bottom: 35, left: 55 };

  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;

  // Compute Scales
  const allEnergies = [
    ...data.map((d) => d.vqeEnergy),
    simulationResult.classicalBindingEnergy,
    simulationResult.hartreeFockReferenceEnergy
  ];
  const minEnergy = Math.min(...allEnergies) - 1.5;
  const maxEnergy = Math.max(...allEnergies) + 1.5;

  const minIter = 1;
  const maxIter = data[data.length - 1].iteration;

  const getX = (iter: number) =>
    padding.left + ((iter - minIter) / (maxIter - minIter || 1)) * plotWidth;

  const getY = (energy: number) =>
    padding.top +
    ((maxEnergy - energy) / (maxEnergy - minEnergy || 1)) * plotHeight;

  // Generate SVG path for VQE Trajectory
  const vqePathD = data
    .map((point, i) => `${i === 0 ? 'M' : 'L'} ${getX(point.iteration)} ${getY(point.vqeEnergy)}`)
    .join(' ');

  // Classical reference line Y
  const classicalY = getY(simulationResult.classicalBindingEnergy);

  // Chemical accuracy band around final ground state
  const finalEnergy = simulationResult.vqeGroundStateEnergy;
  const accuracyTopY = getY(finalEnergy + simulationResult.chemicalAccuracyThreshold);
  const accuracyBottomY = getY(finalEnergy - simulationResult.chemicalAccuracyThreshold);
  const accuracyHeight = Math.abs(accuracyBottomY - accuracyTopY);

  return (
    <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5 shadow-2xl space-y-4">
      {/* Title & Key Metrics Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <TrendingDown className="w-5 h-5 text-cyan-400" />
            VQE Energy Optimization Convergence Curve
          </h3>
          <p className="text-xs text-slate-400">
            Real-time variational state minimization vs. Classical MM-GBSA Force Field
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            Converged ({simulationResult.iterationsToConverge} iters)
          </span>
        </div>
      </div>

      {/* SVG Convergence Chart */}
      <div className="relative w-full bg-slate-950 rounded-xl border border-slate-800/80 p-2 overflow-hidden">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto max-h-64 overflow-visible select-none"
          onMouseLeave={() => setHoveredPoint(null)}
        >
          <defs>
            {/* VQE Line Gradient */}
            <linearGradient id="vqeCurveGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#38BDF8" />
              <stop offset="60%" stopColor="#06B6D4" />
              <stop offset="100%" stopColor="#10B981" />
            </linearGradient>

            {/* Chemical Accuracy Band Gradient */}
            <linearGradient id="chemBandGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#10B981" stopOpacity="0.12" />
              <stop offset="100%" stopColor="#10B981" stopOpacity="0.03" />
            </linearGradient>
          </defs>

          {/* Grid lines (horizontal) */}
          {[-15, -12, -9, -6, -3, 0].map((val) => {
            if (val < minEnergy || val > maxEnergy) return null;
            const y = getY(val);
            return (
              <g key={val}>
                <line
                  x1={padding.left}
                  y1={y}
                  x2={width - padding.right}
                  y2={y}
                  stroke="rgba(255,255,255,0.06)"
                  strokeDasharray="3,3"
                />
                <text
                  x={padding.left - 8}
                  y={y + 3}
                  textAnchor="end"
                  fill="#64748B"
                  fontSize="9"
                  fontFamily="monospace"
                >
                  {val}
                </text>
              </g>
            );
          })}

          {/* Chemical Accuracy ±1.0 kcal/mol Threshold Band */}
          <rect
            x={padding.left}
            y={Math.min(accuracyTopY, accuracyBottomY)}
            width={plotWidth}
            height={accuracyHeight}
            fill="url(#chemBandGrad)"
            stroke="rgba(16,185,129,0.25)"
            strokeDasharray="2,2"
          />
          <text
            x={width - padding.right - 5}
            y={Math.min(accuracyTopY, accuracyBottomY) + 12}
            textAnchor="end"
            fill="#10B981"
            fontSize="8"
            fontFamily="monospace"
          >
            ±1 kcal/mol Chemical Accuracy Band
          </text>

          {/* Classical MM-GBSA Force Field Reference Line */}
          <line
            x1={padding.left}
            y1={classicalY}
            x2={width - padding.right}
            y2={classicalY}
            stroke="#F59E0B"
            strokeWidth="1.5"
            strokeDasharray="5,4"
          />
          <text
            x={padding.left + 8}
            y={classicalY - 6}
            fill="#F59E0B"
            fontSize="9"
            fontFamily="monospace"
            fontWeight="bold"
          >
            Classical MM-GBSA: {simulationResult.classicalBindingEnergy} kcal/mol
          </text>

          {/* VQE Energy Optimization Path */}
          <path
            d={vqePathD}
            fill="none"
            stroke="url(#vqeCurveGrad)"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Data Points with Hover Detection */}
          {data.map((point) => {
            const cx = getX(point.iteration);
            const cy = getY(point.vqeEnergy);
            const isHovered = hoveredPoint?.iteration === point.iteration;

            return (
              <g
                key={point.iteration}
                onMouseEnter={() => setHoveredPoint(point)}
                className="cursor-pointer"
              >
                <circle
                  cx={cx}
                  cy={cy}
                  r={isHovered ? 6 : 2.5}
                  fill={isHovered ? '#FFFFFF' : '#10B981'}
                  stroke="#06B6D4"
                  strokeWidth={isHovered ? 2 : 1}
                />
              </g>
            );
          })}

          {/* X Axis Label */}
          <text
            x={width / 2}
            y={height - 8}
            textAnchor="middle"
            fill="#64748B"
            fontSize="10"
            fontFamily="monospace"
          >
            VQE Optimizer Iterations ({configLabel(simulationResult.config.optimizer)})
          </text>

          {/* Y Axis Label */}
          <text
            x={-height / 2}
            y={14}
            transform="rotate(-90)"
            textAnchor="middle"
            fill="#64748B"
            fontSize="10"
            fontFamily="monospace"
          >
            Binding Energy ΔG (kcal/mol)
          </text>

          {/* Hover Crosshair & Tooltip */}
          {hoveredPoint && (
            <g>
              <line
                x1={getX(hoveredPoint.iteration)}
                y1={padding.top}
                x2={getX(hoveredPoint.iteration)}
                y2={height - padding.bottom}
                stroke="rgba(6,182,212,0.4)"
                strokeDasharray="2,2"
              />
              <rect
                x={Math.min(getX(hoveredPoint.iteration) + 8, width - 150)}
                y={Math.max(getY(hoveredPoint.vqeEnergy) - 40, padding.top)}
                width="135"
                height="45"
                rx="6"
                fill="rgba(15,23,42,0.95)"
                stroke="#06B6D4"
                strokeWidth="1"
              />
              <text
                x={Math.min(getX(hoveredPoint.iteration) + 16, width - 142)}
                y={Math.max(getY(hoveredPoint.vqeEnergy) - 25, padding.top + 15)}
                fill="#FFFFFF"
                fontSize="10"
                fontWeight="bold"
                fontFamily="monospace"
              >
                Iter {hoveredPoint.iteration}: {hoveredPoint.vqeEnergy} kcal/mol
              </text>
              <text
                x={Math.min(getX(hoveredPoint.iteration) + 16, width - 142)}
                y={Math.max(getY(hoveredPoint.vqeEnergy) - 10, padding.top + 30)}
                fill="#38BDF8"
                fontSize="9"
                fontFamily="monospace"
              >
                ΔE_corr: {hoveredPoint.correlationContribution} kcal/mol
              </text>
            </g>
          )}
        </svg>
      </div>

      {/* Numerical Metrics Summary Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
          <span className="text-slate-500 block text-[10px] uppercase">
            VQE Ground State
          </span>
          <span className="text-base font-bold text-emerald-400">
            {simulationResult.vqeGroundStateEnergy} <span className="text-xs text-slate-400">kcal/mol</span>
          </span>
          <span className="text-[10px] text-slate-500 block">
            {simulationResult.vqeEnergyHartree} Hartree
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
          <span className="text-slate-500 block text-[10px] uppercase">
            Electronic Correlation (ΔE)
          </span>
          <span className="text-base font-bold text-cyan-400">
            {simulationResult.electronicCorrelationEnergy} <span className="text-xs text-slate-400">kcal/mol</span>
          </span>
          <span className="text-[10px] text-slate-500 block">
            Hartree-Fock: {simulationResult.hartreeFockReferenceEnergy} kcal
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
          <span className="text-slate-500 block text-[10px] uppercase">
            Classical MM-GBSA
          </span>
          <span className="text-base font-bold text-amber-400">
            {simulationResult.classicalBindingEnergy} <span className="text-xs text-slate-400">kcal/mol</span>
          </span>
          <span className="text-[10px] text-slate-500 block">
            Δ Diff: {(simulationResult.vqeGroundStateEnergy - simulationResult.classicalBindingEnergy).toFixed(2)} kcal
          </span>
        </div>

        <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
          <span className="text-slate-500 block text-[10px] uppercase">
            Predicted Affinity (Kd)
          </span>
          <span className="text-base font-bold text-white">
            {simulationResult.predictedKdQuantum} <span className="text-xs text-cyan-400">{simulationResult.kdUnit}</span>
          </span>
          <span className="text-[10px] text-emerald-400 font-semibold block">
            {simulationResult.bindingAffinityClassification}
          </span>
        </div>
      </div>
    </div>
  );
};

function configLabel(optimizer: string): string {
  switch (optimizer) {
    case 'COBYLA':
      return 'COBYLA Linear Approx';
    case 'SPSA':
      return 'SPSA Stochastic Steps';
    case 'Adam':
      return 'Adam Gradient Steps';
    default:
      return optimizer;
  }
}
