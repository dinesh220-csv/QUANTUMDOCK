import React from 'react';
import {
  Atom,
  Dna,
  Zap,
  Sparkles,
  Share2,
  RotateCcw,
  BookOpen,
  Info
} from 'lucide-react';
import { TARGET_PROTEINS } from '../data/targetsAndLigands';

interface NavbarProps {
  activeStep: number;
  setActiveStep: (step: number) => void;
  onSelectPreset: (targetId: string, ligandId?: string) => void;
  onReset: () => void;
  onOpenDocs: () => void;
  isSimulating: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeStep,
  setActiveStep,
  onSelectPreset,
  onReset,
  onOpenDocs,
  isSimulating
}) => {
  const steps = [
    { num: 1, label: 'Target Protein', icon: Dna },
    { num: 2, label: 'Ligand Candidate', icon: Atom },
    { num: 3, label: 'Quantum VQE', icon: Zap },
    { num: 4, label: 'AI Analyst', icon: Sparkles }
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#090D16]/95 backdrop-blur-md border-b border-cyan-900/40 px-4 lg:px-8 py-3">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Logo and Brand */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 via-cyan-500/10 to-emerald-500/20 border border-cyan-400/40 shadow-[0_0_15px_rgba(6,182,212,0.25)]">
              <Atom className="w-6 h-6 text-cyan-400 animate-spin-slow" />
              <div className="absolute inset-0 rounded-xl bg-cyan-400/10 blur-sm pointer-events-none" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-cyan-300 via-teal-200 to-emerald-400 bg-clip-text text-transparent">
                  QuantumDock
                </span>
                <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-400 border border-cyan-500/30">
                  VQE + AI
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono hidden sm:block">
                AI & Quantum Drug Discovery Studio
              </p>
            </div>
          </div>

          {/* Quick presets dropdown for mobile / tablet */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={onOpenDocs}
              className="p-1.5 rounded-lg bg-slate-800/80 text-slate-300 border border-slate-700 hover:text-cyan-400"
              title="Documentation & Theory"
            >
              <Info className="w-4 h-4" />
            </button>
            <button
              onClick={onReset}
              className="p-1.5 rounded-lg bg-slate-800/80 text-slate-300 border border-slate-700 hover:text-cyan-400"
              title="Reset All"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Workflow Step Indicators */}
        <nav className="flex items-center gap-1.5 sm:gap-2 bg-slate-900/80 p-1 rounded-xl border border-slate-800">
          {steps.map((step) => {
            const Icon = step.icon;
            const isActive = activeStep === step.num;
            const isCompleted = activeStep > step.num;
            return (
              <button
                key={step.num}
                onClick={() => setActiveStep(step.num)}
                disabled={isSimulating}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500 to-teal-500 text-slate-950 font-semibold shadow-[0_0_12px_rgba(6,182,212,0.4)]'
                    : isCompleted
                    ? 'text-cyan-400 hover:bg-slate-800/70'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : isCompleted ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span className="hidden sm:inline">{step.label}</span>
                <span className="sm:hidden">{step.num}</span>
              </button>
            );
          })}
        </nav>

        {/* Quick Presets & Utility Buttons */}
        <div className="hidden md:flex items-center gap-3">
          {/* Quick Presets Selector */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span className="font-mono text-[11px] text-slate-500">Preset:</span>
            <select
              aria-label="Preset Drug Pair"
              onChange={(e) => {
                if (e.target.value) {
                  onSelectPreset(e.target.value);
                }
              }}
              defaultValue="sars-cov-2-mpro"
              className="bg-slate-900 text-cyan-300 border border-slate-700/80 rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:border-cyan-500"
            >
              {TARGET_PROTEINS.map((target) => (
                <option key={target.id} value={target.id}>
                  {target.shortName}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onOpenDocs}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-slate-300 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 rounded-lg transition-colors"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span>Theory</span>
          </button>

          <button
            onClick={onReset}
            className="p-1.5 text-slate-400 hover:text-cyan-400 bg-slate-900/80 hover:bg-slate-800 border border-slate-700 rounded-lg transition-colors"
            title="Reset to Defaults"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
