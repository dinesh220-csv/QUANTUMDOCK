import React, { useRef, useEffect, useState, useCallback } from 'react';
import { TargetProtein, LigandCandidate, HydrogenBondInteraction } from '../types/docking';
import {
  RotateCcw,
  Play,
  Pause,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  Eye,
  EyeOff,
  Layers,
  Sparkles,
  Info
} from 'lucide-react';

interface MolecularViewer3DProps {
  target: TargetProtein;
  ligand: LigandCandidate;
  activeInteractions?: HydrogenBondInteraction[];
}

// Element color palette according to CPK standards
const ELEMENT_COLORS: Record<string, { fill: string; stroke: string; glow: string; radius: number }> = {
  C: { fill: '#38BDF8', stroke: '#0284C7', glow: 'rgba(56,189,248,0.4)', radius: 10 },
  N: { fill: '#60A5FA', stroke: '#2563EB', glow: 'rgba(96,165,250,0.4)', radius: 11 },
  O: { fill: '#F87171', stroke: '#DC2626', glow: 'rgba(248,113,113,0.4)', radius: 10 },
  S: { fill: '#FBBF24', stroke: '#D97706', glow: 'rgba(251,191,36,0.4)', radius: 14 },
  F: { fill: '#34D399', stroke: '#059669', glow: 'rgba(52,211,153,0.4)', radius: 9 },
  P: { fill: '#FB923C', stroke: '#EA580C', glow: 'rgba(251,146,60,0.4)', radius: 13 },
  H: { fill: '#E2E8F0', stroke: '#94A3B8', glow: 'rgba(226,232,240,0.2)', radius: 6 },
  Cl: { fill: '#4ADE80', stroke: '#16A34A', glow: 'rgba(74,222,128,0.4)', radius: 13 }
};

export const MolecularViewer3D: React.FC<MolecularViewer3DProps> = ({
  target,
  ligand,
  activeInteractions
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Camera state
  const [rotationX, setRotationX] = useState<number>(0.35);
  const [rotationY, setRotationY] = useState<number>(-0.6);
  const [zoom, setZoom] = useState<number>(38); // pixels per Ångström
  const [panX, setPanX] = useState<number>(0);
  const [panY, setPanY] = useState<number>(0);

  // Interaction controls
  const [isAutoRotating, setIsAutoRotating] = useState<boolean>(true);
  const [showPocketSurface, setShowPocketSurface] = useState<boolean>(true);
  const [showResidueLabels, setShowResidueLabels] = useState<boolean>(true);
  const [showDistanceTags, setShowDistanceTags] = useState<boolean>(true);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [hoveredAtom, setHoveredAtom] = useState<string | null>(null);

  // Mouse drag tracking
  const isDragging = useRef<boolean>(false);
  const isPanning = useRef<boolean>(false);
  const lastMousePos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  const interactions =
    activeInteractions && activeInteractions.length > 0
      ? activeInteractions
      : ligand.targetInteractions[target.id] || [];

  // Reset Camera View
  const handleResetCamera = useCallback(() => {
    setRotationX(0.35);
    setRotationY(-0.6);
    setZoom(38);
    setPanX(0);
    setPanY(0);
  }, []);

  // Zoom helpers
  const handleZoomIn = () => setZoom((z) => Math.min(75, z + 6));
  const handleZoomOut = () => setZoom((z) => Math.max(18, z - 6));

  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  // Mouse event listeners for 3D rotation & pan
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (e.button === 2) {
      isPanning.current = true;
    } else {
      isDragging.current = true;
      setIsAutoRotating(false);
    }
    lastMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const deltaX = e.clientX - lastMousePos.current.x;
    const deltaY = e.clientY - lastMousePos.current.y;
    lastMousePos.current = { x: e.clientX, y: e.clientY };

    if (isDragging.current) {
      setRotationY((ry) => ry + deltaX * 0.012);
      setRotationX((rx) => Math.max(-Math.PI / 2, Math.min(Math.PI / 2, rx + deltaY * 0.012)));
    } else if (isPanning.current) {
      setPanX((px) => px + deltaX);
      setPanY((py) => py + deltaY);
    }
  };

  const handleMouseUp = () => {
    isDragging.current = false;
    isPanning.current = false;
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const zoomDelta = e.deltaY < 0 ? 3 : -3;
    setZoom((z) => Math.max(18, Math.min(75, z + zoomDelta)));
  };

  // Touch handlers for mobile
  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (e.touches.length === 1) {
      isDragging.current = true;
      setIsAutoRotating(false);
      lastMousePos.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (isDragging.current && e.touches.length === 1) {
      const deltaX = e.touches[0].clientX - lastMousePos.current.x;
      const deltaY = e.touches[0].clientY - lastMousePos.current.y;
      lastMousePos.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      setRotationY((ry) => ry + deltaX * 0.015);
      setRotationX((rx) => Math.max(-Math.PI / 2, Math.min(Math.PI / 2, rx + deltaY * 0.015)));
    }
  };

  // Animation Loop: Render 3D Canvas
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let localRotY = rotationY;

    const render = () => {
      if (isAutoRotating) {
        localRotY += 0.005;
        setRotationY(localRotY);
      }

      // Handle high-DPI
      const dpr = window.devicePixelRatio || 1;
      const width = canvas.clientWidth;
      const height = canvas.clientHeight;
      if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
        canvas.width = width * dpr;
        canvas.height = height * dpr;
      }
      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, width, height);

      // Deep dark laboratory background with radial gradient
      const bgGrad = ctx.createRadialGradient(
        width / 2 + panX,
        height / 2 + panY,
        20,
        width / 2,
        height / 2,
        Math.max(width, height) * 0.7
      );
      bgGrad.addColorStop(0, '#0c172b');
      bgGrad.addColorStop(0.5, '#070d1a');
      bgGrad.addColorStop(1, '#04070e');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // Draw subtle grid lines on the background
      ctx.strokeStyle = 'rgba(6,182,212,0.04)';
      ctx.lineWidth = 1;
      for (let x = 0; x < width; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      const centerX = width / 2 + panX;
      const centerY = height / 2 + panY;

      // 3D Rotation matrices
      const cosX = Math.cos(rotationX);
      const sinX = Math.sin(rotationX);
      const cosY = Math.cos(rotationY);
      const sinY = Math.sin(rotationY);

      // Project 3D coordinate to 2D screen coordinate with depth Z
      const project = (x: number, y: number, z: number) => {
        // Rotate around Y
        const x1 = x * cosY + z * sinY;
        const z1 = -x * sinY + z * cosY;
        // Rotate around X
        const y2 = y * cosX - z1 * sinX;
        const z2 = y * sinX + z1 * cosX;

        // Perspective projection
        const fov = 400;
        const scale = (fov / (fov + z2)) * (zoom / 30);
        const screenX = centerX + x1 * scale * 30;
        const screenY = centerY - y2 * scale * 30;
        return { x: screenX, y: screenY, z: z2, scale };
      };

      // 1. Draw Pocket Surface contour / Wireframe mesh if enabled
      if (showPocketSurface && target.keyResidues.length > 0) {
        ctx.save();
        ctx.strokeStyle = 'rgba(6,182,212,0.18)';
        ctx.fillStyle = 'rgba(6,182,212,0.03)';
        ctx.lineWidth = 1;

        const pocketPoints = target.keyResidues.map((res) => project(res.x, res.y, res.z));
        if (pocketPoints.length >= 3) {
          ctx.beginPath();
          ctx.moveTo(pocketPoints[0].x, pocketPoints[0].y);
          for (let i = 1; i < pocketPoints.length; i++) {
            ctx.lineTo(pocketPoints[i].x, pocketPoints[i].y);
          }
          ctx.closePath();
          ctx.fill();
          ctx.stroke();

          // Pocket mesh diagonals
          for (let i = 0; i < pocketPoints.length; i++) {
            for (let j = i + 2; j < pocketPoints.length; j++) {
              ctx.beginPath();
              ctx.setLineDash([3, 4]);
              ctx.strokeStyle = 'rgba(6,182,212,0.08)';
              ctx.moveTo(pocketPoints[i].x, pocketPoints[i].y);
              ctx.lineTo(pocketPoints[j].x, pocketPoints[j].y);
              ctx.stroke();
            }
          }
          ctx.setLineDash([]);
        }
        ctx.restore();
      }

      // Collect all 3D drawable elements for global Z-depth sorting
      interface DrawItem {
        type: 'bond' | 'atom' | 'residue' | 'interaction';
        z: number;
        draw: () => void;
      }
      const drawQueue: DrawItem[] = [];

      // A. Ligand Bonds
      ligand.structure3D.bonds.forEach((bond) => {
        const atomFrom = ligand.structure3D.atoms[bond.from];
        const atomTo = ligand.structure3D.atoms[bond.to];
        if (!atomFrom || !atomTo) return;

        const p1 = project(atomFrom.x, atomFrom.y, atomFrom.z);
        const p2 = project(atomTo.x, atomTo.y, atomTo.z);
        const midZ = (p1.z + p2.z) / 2;

        drawQueue.push({
          type: 'bond',
          z: midZ,
          draw: () => {
            const bondWidth = Math.max(2, 3.5 * ((p1.scale + p2.scale) / 2));
            ctx.save();
            ctx.lineCap = 'round';

            if (bond.order === 2) {
              // Double bond: draw two parallel lines
              const dx = p2.x - p1.x;
              const dy = p2.y - p1.y;
              const len = Math.sqrt(dx * dx + dy * dy) || 1;
              const nx = (-dy / len) * (bondWidth * 0.7);
              const ny = (dx / len) * (bondWidth * 0.7);

              ctx.lineWidth = bondWidth * 0.7;
              ctx.strokeStyle = '#475569';
              ctx.beginPath();
              ctx.moveTo(p1.x + nx, p1.y + ny);
              ctx.lineTo(p2.x + nx, p2.y + ny);
              ctx.stroke();

              ctx.beginPath();
              ctx.moveTo(p1.x - nx, p1.y - ny);
              ctx.lineTo(p2.x - nx, p2.y - ny);
              ctx.stroke();
            } else if (bond.order === 3) {
              // Triple bond
              ctx.lineWidth = bondWidth * 0.5;
              ctx.strokeStyle = '#38BDF8';
              ctx.beginPath();
              ctx.moveTo(p1.x, p1.y);
              ctx.lineTo(p2.x, p2.y);
              ctx.stroke();
            } else {
              // Single bond: dual gradient coloring between atoms
              const grad = ctx.createLinearGradient(p1.x, p1.y, p2.x, p2.y);
              const c1 = ELEMENT_COLORS[atomFrom.element]?.fill || '#94A3B8';
              const c2 = ELEMENT_COLORS[atomTo.element]?.fill || '#94A3B8';
              grad.addColorStop(0, c1);
              grad.addColorStop(1, c2);

              ctx.lineWidth = bondWidth;
              ctx.strokeStyle = grad;
              ctx.beginPath();
              ctx.moveTo(p1.x, p1.y);
              ctx.lineTo(p2.x, p2.y);
              ctx.stroke();
            }
            ctx.restore();
          }
        });
      });

      // B. Ligand Atoms (3D Shaded Spheres)
      ligand.structure3D.atoms.forEach((atom) => {
        const p = project(atom.x, atom.y, atom.z);
        const elem = ELEMENT_COLORS[atom.element] || ELEMENT_COLORS.C;
        const radius = Math.max(4, elem.radius * p.scale);

        drawQueue.push({
          type: 'atom',
          z: p.z,
          draw: () => {
            ctx.save();
            // Outer glow
            ctx.beginPath();
            ctx.arc(p.x, p.y, radius * 1.5, 0, Math.PI * 2);
            ctx.fillStyle = elem.glow;
            ctx.fill();

            // 3D Sphere shading
            const sphereGrad = ctx.createRadialGradient(
              p.x - radius * 0.35,
              p.y - radius * 0.35,
              radius * 0.1,
              p.x,
              p.y,
              radius
            );
            sphereGrad.addColorStop(0, '#FFFFFF');
            sphereGrad.addColorStop(0.3, elem.fill);
            sphereGrad.addColorStop(1, elem.stroke);

            ctx.beginPath();
            ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
            ctx.fillStyle = sphereGrad;
            ctx.shadowColor = elem.glow;
            ctx.shadowBlur = 6;
            ctx.fill();

            // Element letter label on larger atoms
            if (radius > 9 && atom.element !== 'H') {
              ctx.fillStyle = '#0F172A';
              ctx.font = `bold ${Math.round(radius * 0.9)}px JetBrains Mono, monospace`;
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillText(atom.element, p.x, p.y);
            }
            ctx.restore();
          }
        });
      });

      // C. Target Pocket Residues (Spheres + Label Tags)
      target.keyResidues.forEach((res) => {
        const p = project(res.x, res.y, res.z);
        const radius = Math.max(6, 11 * p.scale);

        let roleColor = '#06B6D4'; // binding pocket cyan
        let strokeColor = '#0891B2';
        let badgeBg = 'rgba(6,182,212,0.9)';
        if (res.role === 'catalytic') {
          roleColor = '#F43F5E'; // rose/crimson
          strokeColor = '#BE123C';
          badgeBg = 'rgba(244,63,94,0.95)';
        } else if (res.role === 'gatekeeper') {
          roleColor = '#F59E0B'; // amber
          strokeColor = '#B45309';
          badgeBg = 'rgba(245,158,11,0.95)';
        } else if (res.role === 'hydrophobic_wall') {
          roleColor = '#10B981'; // emerald
          strokeColor = '#059669';
          badgeBg = 'rgba(16,185,129,0.95)';
        }

        drawQueue.push({
          type: 'residue',
          z: p.z,
          draw: () => {
            ctx.save();
            // Translucent halo
            ctx.beginPath();
            ctx.arc(p.x, p.y, radius * 2.2, 0, Math.PI * 2);
            ctx.fillStyle = `${roleColor}18`;
            ctx.fill();

            // Main residue node
            const resGrad = ctx.createRadialGradient(
              p.x - radius * 0.3,
              p.y - radius * 0.3,
              radius * 0.1,
              p.x,
              p.y,
              radius
            );
            resGrad.addColorStop(0, '#FFFFFF');
            resGrad.addColorStop(0.35, roleColor);
            resGrad.addColorStop(1, strokeColor);

            ctx.beginPath();
            ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
            ctx.fillStyle = resGrad;
            ctx.strokeStyle = strokeColor;
            ctx.lineWidth = 1.5;
            ctx.stroke();
            ctx.fill();

            // Residue label tag
            if (showResidueLabels) {
              const label = `${res.name}${res.number}`;
              ctx.font = 'bold 10px JetBrains Mono, monospace';
              const textWidth = ctx.measureText(label).width;
              const boxPad = 4;
              const tagY = p.y - radius - 14;

              // Tag background pill
              ctx.fillStyle = badgeBg;
              ctx.beginPath();
              ctx.roundRect(p.x - textWidth / 2 - boxPad, tagY, textWidth + boxPad * 2, 16, 4);
              ctx.fill();

              // Tag text
              ctx.fillStyle = '#FFFFFF';
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillText(label, p.x, tagY + 8);

              // Little pointer line
              ctx.beginPath();
              ctx.strokeStyle = badgeBg;
              ctx.lineWidth = 1;
              ctx.moveTo(p.x, tagY + 16);
              ctx.lineTo(p.x, p.y - radius);
              ctx.stroke();
            }
            ctx.restore();
          }
        });
      });

      // D. Active Hydrogen Bonds & Covalent Warhead Vectors
      interactions.forEach((inter) => {
        const p1 = project(inter.startCoord[0], inter.startCoord[1], inter.startCoord[2]);
        const p2 = project(inter.endCoord[0], inter.endCoord[1], inter.endCoord[2]);
        const midZ = (p1.z + p2.z) / 2;

        let lineColor = '#F43F5E'; // red/pink for covalent
        let dashStyle = [5, 4];
        if (inter.type === 'hydrogen_bond') {
          lineColor = '#38BDF8'; // cyan H-bond
          dashStyle = [4, 3];
        } else if (inter.type === 'pi_stacking') {
          lineColor = '#A855F7'; // purple pi-stacking
          dashStyle = [3, 3];
        }

        drawQueue.push({
          type: 'interaction',
          z: midZ,
          draw: () => {
            ctx.save();
            ctx.beginPath();
            ctx.setLineDash(dashStyle);
            ctx.strokeStyle = lineColor;
            ctx.lineWidth = 2;
            ctx.shadowColor = lineColor;
            ctx.shadowBlur = 8;
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();

            // Distance Tag in Ångströms
            if (showDistanceTags) {
              const midX = (p1.x + p2.x) / 2;
              const midY = (p1.y + p2.y) / 2;
              const distText = `${inter.distanceAngstroms.toFixed(2)} Å`;

              ctx.font = 'bold 9px JetBrains Mono, monospace';
              const textWidth = ctx.measureText(distText).width;
              ctx.fillStyle = 'rgba(15,23,42,0.85)';
              ctx.strokeStyle = lineColor;
              ctx.lineWidth = 1;
              ctx.beginPath();
              ctx.roundRect(midX - textWidth / 2 - 3, midY - 7, textWidth + 6, 14, 3);
              ctx.fill();
              ctx.stroke();

              ctx.fillStyle = '#FFFFFF';
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillText(distText, midX, midY);
            }
            ctx.restore();
          }
        });
      });

      // Sort all items back-to-front (Z-sort: higher z means deeper in screen, draw first)
      drawQueue.sort((a, b) => b.z - a.z);
      drawQueue.forEach((item) => item.draw());

      ctx.restore();
      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [
    rotationX,
    rotationY,
    zoom,
    panX,
    panY,
    isAutoRotating,
    showPocketSurface,
    showResidueLabels,
    showDistanceTags,
    target,
    ligand,
    interactions
  ]);

  return (
    <div
      ref={containerRef}
      className={`relative w-full rounded-2xl overflow-hidden border border-cyan-900/60 bg-[#070D1A] shadow-2xl ${
        isFullscreen ? 'h-screen fixed inset-0 z-50 rounded-none' : 'h-[460px] md:h-[520px]'
      }`}
    >
      {/* 3D Canvas */}
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleMouseUp}
        onContextMenu={(e) => e.preventDefault()}
        className="w-full h-full cursor-grab active:cursor-grabbing block"
      />

      {/* Top Floating Info Bar */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-2 bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/70 text-xs shadow-lg pointer-events-auto">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
          <span className="font-bold text-white tracking-wide">
            {ligand.name}
          </span>
          <span className="text-slate-500 font-mono">docked in</span>
          <span className="font-semibold text-cyan-300">
            {target.shortName}
          </span>
          <span className="font-mono text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
            PDB: {target.pdbId}
          </span>
        </div>

        {/* Legend */}
        <div className="hidden lg:flex items-center gap-2.5 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 text-[10px] font-mono pointer-events-auto">
          <div className="flex items-center gap-1 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-[#38BDF8]" /> C
          </div>
          <div className="flex items-center gap-1 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-[#60A5FA]" /> N
          </div>
          <div className="flex items-center gap-1 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-[#F87171]" /> O
          </div>
          <div className="flex items-center gap-1 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-[#FBBF24]" /> S
          </div>
          <div className="flex items-center gap-1 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-[#34D399]" /> F
          </div>
          <div className="h-3 w-px bg-slate-700 mx-0.5" />
          <div className="flex items-center gap-1 text-rose-300">
            <span className="w-2 h-2 rounded-full bg-rose-500" /> Catalytic
          </div>
          <div className="flex items-center gap-1 text-cyan-300">
            <span className="w-2 h-2 rounded-full bg-cyan-400" /> Pocket
          </div>
        </div>
      </div>

      {/* Floating 3D Interaction Toolbar */}
      <div className="absolute bottom-3 left-3 flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-700/70 shadow-xl text-slate-300">
        <button
          onClick={() => setIsAutoRotating(!isAutoRotating)}
          className={`p-1.5 rounded-lg transition-colors ${
            isAutoRotating ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40' : 'hover:bg-slate-800 text-slate-400'
          }`}
          title={isAutoRotating ? 'Pause Orbit' : 'Auto Orbit 3D'}
        >
          {isAutoRotating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </button>

        <button
          onClick={handleZoomIn}
          className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          title="Zoom In"
        >
          <ZoomIn className="w-4 h-4" />
        </button>

        <button
          onClick={handleZoomOut}
          className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          title="Zoom Out"
        >
          <ZoomOut className="w-4 h-4" />
        </button>

        <button
          onClick={handleResetCamera}
          className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-cyan-400 transition-colors"
          title="Reset Camera Center"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        <div className="h-4 w-px bg-slate-800 mx-0.5" />

        <button
          onClick={() => setShowPocketSurface(!showPocketSurface)}
          className={`p-1.5 rounded-lg transition-colors text-xs flex items-center gap-1 ${
            showPocketSurface ? 'bg-cyan-950/70 text-cyan-400 border border-cyan-800' : 'text-slate-400 hover:bg-slate-800'
          }`}
          title="Toggle Pocket Surface Mesh"
        >
          <Layers className="w-3.5 h-3.5" />
          <span className="hidden sm:inline text-[11px]">Surface</span>
        </button>

        <button
          onClick={() => setShowResidueLabels(!showResidueLabels)}
          className={`p-1.5 rounded-lg transition-colors text-xs flex items-center gap-1 ${
            showResidueLabels ? 'bg-cyan-950/70 text-cyan-400 border border-cyan-800' : 'text-slate-400 hover:bg-slate-800'
          }`}
          title="Toggle Pocket Residue Labels"
        >
          <Eye className="w-3.5 h-3.5" />
          <span className="hidden sm:inline text-[11px]">Labels</span>
        </button>

        <button
          onClick={() => setShowDistanceTags(!showDistanceTags)}
          className={`p-1.5 rounded-lg transition-colors text-xs flex items-center gap-1 ${
            showDistanceTags ? 'bg-cyan-950/70 text-cyan-400 border border-cyan-800' : 'text-slate-400 hover:bg-slate-800'
          }`}
          title="Toggle H-Bond Distances (Å)"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline text-[11px]">Distances</span>
        </button>

        <button
          onClick={toggleFullscreen}
          className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          title="Toggle Fullscreen"
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>
      </div>

      {/* Bottom Right Controls Help Hint */}
      <div className="absolute bottom-3 right-3 hidden sm:flex items-center gap-1.5 bg-slate-900/75 backdrop-blur-md px-2.5 py-1 rounded-lg border border-slate-800 text-[10px] text-slate-400 font-mono">
        <Info className="w-3 h-3 text-cyan-400" />
        <span>Drag to rotate • Wheel to zoom • Right-click to pan</span>
      </div>
    </div>
  );
};
