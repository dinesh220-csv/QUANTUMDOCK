import React from 'react';
import { DockingSimulationResult } from '../types/docking';
import {
  Cpu,
  Layers,
  Zap,
  Clock,
  ShieldCheck,
  Check,
  X,
  Gauge,
  ArrowRight
} from 'lucide-react';

interface ComparisonMetricsProps {
  result: DockingSimulationResult;
}

export const ComparisonMetrics: React.FC<ComparisonMetricsProps> = ({ result }) => {
  const energyDiff = (result.vqeGroundStateEnergy - result.classicalBindingEnergy).toFixed(2);
  const diffSign = parseFloat(energyDiff) > 0 ? '+' : '';

  return (
    <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5 shadow-2xl space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
            <Gauge className="w-5 h-5 text-cyan-400" />
            Classical vs. Quantum Simulation Benchmark
          </h3>
          <p className="text-xs text-slate-400">
            Comparing empirical force field approximations (MM-GBSA) against Hamiltonian VQE eigensolver
          </p>
        </div>
        <div className="text-right">
          <span className="text-[10px] font-mono text-slate-400 block">Correlation Shift</span>
          <span className="text-xs font-bold font-mono text-cyan-400">
            {diffSign}{energyDiff} kcal/mol
          </span>
        </div>
      </div>

      {/* Comparison Cards / Table */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Classical Column */}
        <div className="p-4 rounded-xl bg-slate-950/70 border border-amber-900/40 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <h4 className="text-sm font-bold text-amber-300">
                Classical Force Field (MM-GBSA)
              </h4>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800">
              CPU Empiric
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Binding Free Energy (ΔG):</span>
              <span className="font-bold text-amber-400">{result.classicalBindingEnergy} kcal/mol</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Van der Waals (LJ 12-6):</span>
              <span className="text-slate-300">{result.classicalVdwEnergy} kcal/mol</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Coulombic Electrostatics:</span>
              <span className="text-slate-300">{result.classicalCoulombEnergy} kcal/mol</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Desolvation Penalty:</span>
              <span className="text-slate-300">+{result.classicalSolvationPenalty} kcal/mol</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Electron Correlation:</span>
              <span className="text-rose-400 font-semibold flex items-center gap-1">
                <X className="w-3 h-3" /> None (Mean-field)
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Covalent Bond Formation:</span>
              <span className="text-rose-400 font-semibold flex items-center gap-1">
                <X className="w-3 h-3" /> Approximated
              </span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Classical Runtime:</span>
              <span className="text-slate-300">{result.classicalRuntimeSec} sec</span>
            </div>
          </div>
        </div>

        {/* Quantum Column */}
        <div className="p-4 rounded-xl bg-slate-950/70 border border-cyan-800/60 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
              <h4 className="text-sm font-bold text-cyan-300">
                Simulated Quantum VQE
              </h4>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-700">
              QPU + Classical Loop
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Ground State Energy (E₀):</span>
              <span className="font-bold text-emerald-400">{result.vqeGroundStateEnergy} kcal/mol</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Hartree-Fock Reference:</span>
              <span className="text-slate-300">{result.hartreeFockReferenceEnergy} kcal/mol</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Dynamic Correlation (ΔE_corr):</span>
              <span className="text-cyan-400 font-bold">{result.electronicCorrelationEnergy} kcal/mol</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Active Qubits / CNOTs:</span>
              <span className="text-slate-300">{result.activeQubitsUsed} Qubits / {result.cnotGateCount} Gates</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Quantum State Fidelity:</span>
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <Check className="w-3 h-3" /> {(result.quantumStateFidelity * 100).toFixed(2)}%
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Crystal Pose Docking RMSD:</span>
              <span className="text-cyan-300 font-semibold">{result.rmsdFromCrystal} Å</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Simulated QPU Runtime:</span>
              <span className="text-slate-300">{result.quantumRuntimeSec} sec</span>
            </div>
          </div>
        </div>
      </div>

      {/* Scientific Rationale Banner */}
      <div className="p-3.5 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-xs text-slate-300 flex items-start gap-3">
        <Zap className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong className="text-cyan-300">Why Quantum VQE Outperforms Classical Force Fields:</strong> Standard MM-GBSA treats atoms as rigid point charges with fixed Lennard-Jones spheres, frequently missing multi-electron dispersion and orbital hybridization during covalent warhead adduct formation. VQE directly solves the electronic Schrödinger equation within the active space, providing chemical accuracy (±1.0 kcal/mol) for reliable lead compound ranking.
        </p>
      </div>
    </div>
  );
};
