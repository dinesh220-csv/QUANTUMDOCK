import React, { useState } from 'react';
import { LigandCandidate, TargetProtein } from '../types/docking';
import { CANDIDATE_LIGANDS, evaluateLipinski } from '../data/targetsAndLigands';
import {
  Atom,
  CheckCircle2,
  AlertTriangle,
  PlusCircle,
  Copy,
  Check,
  ShieldCheck,
  Zap,
  ArrowRight,
  ArrowLeft,
  Sparkles
} from 'lucide-react';

interface LigandSelectorProps {
  selectedLigand: LigandCandidate;
  selectedTarget: TargetProtein;
  onSelectLigand: (ligand: LigandCandidate) => void;
  onProceed: () => void;
  onBack: () => void;
  onAddCustomLigand: (ligand: LigandCandidate) => void;
}

export const LigandSelector: React.FC<LigandSelectorProps> = ({
  selectedLigand,
  selectedTarget,
  onSelectLigand,
  onProceed,
  onBack,
  onAddCustomLigand
}) => {
  const [copiedSmilesId, setCopiedSmilesId] = useState<string | null>(null);
  const [showCustomModal, setShowCustomModal] = useState(false);

  // Custom ligand inputs
  const [customName, setCustomName] = useState('');
  const [customSmiles, setCustomSmiles] = useState('');
  const [customMw, setCustomMw] = useState('420.5');
  const [customLogP, setCustomLogP] = useState('2.4');
  const [customHbd, setCustomHbd] = useState('2');
  const [customHba, setCustomHba] = useState('5');
  const [customDesc, setCustomDesc] = useState('');

  const handleCopySmiles = (id: string, smiles: string) => {
    navigator.clipboard.writeText(smiles);
    setCopiedSmilesId(id);
    setTimeout(() => setCopiedSmilesId(null), 1800);
  };

  const handleCreateCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim() || !customSmiles.trim()) return;

    const mw = parseFloat(customMw) || 400;
    const logP = parseFloat(customLogP) || 2.5;
    const hbd = parseInt(customHbd, 10) || 2;
    const hba = parseInt(customHba, 10) || 5;

    const newLigand: LigandCandidate = {
      id: `custom-ligand-${Date.now()}`,
      name: customName.trim(),
      tradeName: 'Custom Candidate',
      smiles: customSmiles.trim(),
      formula: 'C22H26N4O3',
      molecularWeight: mw,
      logP: logP,
      hBondDonors: hbd,
      hBondAcceptors: hba,
      rotatableBonds: 5,
      tpsa: 84.5,
      description: customDesc.trim() || 'Custom synthetic small molecule candidate.',
      mechanism: 'Simulated binding and competitive displacement.',
      structure3D: {
        atoms: [
          { id: 0, element: 'C', x: 0.0, y: 0.0, z: 0.0, label: 'C1' },
          { id: 1, element: 'C', x: 1.2, y: 0.5, z: 0.1, label: 'C2' },
          { id: 2, element: 'N', x: 2.3, y: -0.2, z: 0.0, label: 'N3' },
          { id: 3, element: 'C', x: 3.4, y: 0.6, z: 0.2, label: 'C4' },
          { id: 4, element: 'O', x: 3.5, y: 1.8, z: 0.4, label: 'O5' },
          { id: 5, element: 'C', x: -1.2, y: 0.7, z: 0.1, label: 'C6' },
          { id: 6, element: 'O', x: -2.3, y: 0.1, z: 0.0, label: 'O7' }
        ],
        bonds: [
          { from: 0, to: 1, order: 1 },
          { from: 1, to: 2, order: 1 },
          { from: 2, to: 3, order: 1 },
          { from: 3, to: 4, order: 2 },
          { from: 0, to: 5, order: 1 },
          { from: 5, to: 6, order: 1 }
        ]
      },
      targetInteractions: {
        [selectedTarget.id]: [
          {
            id: 'custom-int-1',
            donorElement: 'Pocket Amide',
            donorResidue: selectedTarget.keyResidues[0]?.name + selectedTarget.keyResidues[0]?.number || 'Res1',
            acceptorElement: 'Carbonyl Oxygen',
            acceptorAtom: 'O5',
            distanceAngstroms: 2.45,
            energyKcalMol: -4.1,
            type: 'hydrogen_bond',
            startCoord: [selectedTarget.keyResidues[0]?.x || 0, selectedTarget.keyResidues[0]?.y || 0, selectedTarget.keyResidues[0]?.z || 0],
            endCoord: [3.5, 1.8, 0.4]
          }
        ]
      }
    };

    onAddCustomLigand(newLigand);
    onSelectLigand(newLigand);
    setShowCustomModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-emerald-950/40 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-mono">
              Step 2 of 4
            </span>
            <span className="text-xs text-slate-400">Ligand Library & Physicochemical Screening</span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight">
            Select Small-Molecule Candidate
          </h2>
          <p className="text-sm text-slate-400 max-w-2xl mt-1">
            Targeting <span className="text-cyan-300 font-semibold">{selectedTarget.shortName}</span>. Choose an inhibitor or design a custom candidate with specific Lipinski drug-likeness parameters.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-xl transition-all"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Target</span>
          </button>
          <button
            onClick={() => setShowCustomModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-600/40 rounded-xl transition-all shadow-[0_0_15px_rgba(16,185,129,0.15)]"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Custom Molecule / SMILES</span>
          </button>
          <button
            onClick={onProceed}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-emerald-400 to-cyan-400 hover:from-emerald-300 hover:to-cyan-300 rounded-xl transition-all shadow-[0_0_20px_rgba(16,185,129,0.35)]"
          >
            <span>Proceed to VQE</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Ligands Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {CANDIDATE_LIGANDS.map((ligand) => {
          const isSelected = selectedLigand.id === ligand.id;
          const isRecommended = selectedTarget.defaultLigandId === ligand.id;
          const lipinski = evaluateLipinski(ligand);

          return (
            <div
              key={ligand.id}
              onClick={() => onSelectLigand(ligand)}
              className={`relative cursor-pointer rounded-2xl p-5 transition-all flex flex-col justify-between border ${
                isSelected
                  ? 'bg-gradient-to-b from-emerald-950/60 via-slate-900/90 to-slate-950 border-emerald-400 shadow-[0_0_25px_rgba(16,185,129,0.25)] ring-1 ring-emerald-400/50'
                  : 'bg-slate-900/70 hover:bg-slate-900/90 border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Badges row */}
              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-1.5 flex-wrap">
                  {isRecommended && (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      <Zap className="w-3 h-3 text-cyan-400" />
                      Target Native Pair
                    </span>
                  )}
                  {lipinski.compliant ? (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                      <ShieldCheck className="w-3 h-3" />
                      Lipinski Pass
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-amber-500/15 text-amber-400 border border-amber-500/30">
                      <AlertTriangle className="w-3 h-3" />
                      {lipinski.violations.length} Violation{lipinski.violations.length > 1 ? 's' : ''}
                    </span>
                  )}
                </div>

                {isSelected && (
                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-bold tracking-wider uppercase">
                    <CheckCircle2 className="w-3 h-3" />
                    Selected
                  </div>
                )}
              </div>

              {/* Title & Trade Name */}
              <div>
                <h3 className="text-base font-bold text-white">
                  {ligand.name}
                </h3>
                {ligand.tradeName && (
                  <p className="text-xs text-slate-400 font-medium">
                    {ligand.tradeName}
                  </p>
                )}

                <p className="text-xs text-slate-300 mt-2 line-clamp-2 leading-relaxed">
                  {ligand.description}
                </p>

                {/* Physicochemical Properties Matrix */}
                <div className="grid grid-cols-3 gap-2 mt-4 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-[11px] font-mono">
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase">MW</span>
                    <span className={`font-semibold ${ligand.molecularWeight > 500 ? 'text-amber-400' : 'text-slate-200'}`}>
                      {ligand.molecularWeight.toFixed(1)} <span className="text-[9px] text-slate-500">Da</span>
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase">LogP</span>
                    <span className={`font-semibold ${ligand.logP > 5.0 ? 'text-amber-400' : 'text-slate-200'}`}>
                      {ligand.logP.toFixed(2)}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase">TPSA</span>
                    <span className="text-slate-200 font-semibold">
                      {ligand.tpsa} <span className="text-[9px] text-slate-500">Å²</span>
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase">H-Donors</span>
                    <span className={`font-semibold ${ligand.hBondDonors > 5 ? 'text-amber-400' : 'text-slate-200'}`}>
                      {ligand.hBondDonors}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase">H-Acceptors</span>
                    <span className={`font-semibold ${ligand.hBondAcceptors > 10 ? 'text-amber-400' : 'text-slate-200'}`}>
                      {ligand.hBondAcceptors}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase">Rot. Bonds</span>
                    <span className="text-slate-200 font-semibold">
                      {ligand.rotatableBonds}
                    </span>
                  </div>
                </div>
              </div>

              {/* SMILES Section */}
              <div className="mt-4 pt-3 border-t border-slate-800/60">
                <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                  <span className="font-mono">SMILES Structure</span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCopySmiles(ligand.id, ligand.smiles);
                    }}
                    className="flex items-center gap-1 hover:text-cyan-400 transition-colors"
                  >
                    {copiedSmilesId === ligand.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="p-2 bg-slate-950 rounded-lg border border-slate-800 text-[10px] font-mono text-emerald-400/80 truncate">
                  {ligand.smiles}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Ligand Summary Bar */}
      <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <Atom className="w-5 h-5" />
          </div>
          <div>
            <div className="text-slate-300 font-medium">
              Ready for Quantum Docking: <span className="text-white font-bold">{selectedLigand.name}</span>
            </div>
            <div className="text-slate-400 text-[11px]">
              Target: <span className="text-cyan-400">{selectedTarget.shortName}</span> • Formula: {selectedLigand.formula} • MW: {selectedLigand.molecularWeight} g/mol
            </div>
          </div>
        </div>
        <button
          onClick={onProceed}
          className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-emerald-400 to-cyan-400 hover:from-emerald-300 hover:to-cyan-300 rounded-lg transition-all"
        >
          <span>Run Quantum VQE Simulation</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Custom Ligand Modal */}
      {showCustomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-slate-900 border border-emerald-800/80 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Atom className="w-5 h-5 text-emerald-400" />
                Add Custom Drug Molecule
              </h3>
              <button
                onClick={() => setShowCustomModal(false)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateCustom} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Compound Name *
                </label>
                <input
                  type="text"
                  required
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="e.g., Mol-QD-901"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Canonical SMILES String *
                </label>
                <input
                  type="text"
                  required
                  value={customSmiles}
                  onChange={(e) => setCustomSmiles(e.target.value)}
                  placeholder="e.g., CC(=O)Oc1ccccc1C(=O)O"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-emerald-300 font-mono placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Molecular Weight (Da)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={customMw}
                    onChange={(e) => setCustomMw(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    LogP
                  </label>
                  <input
                    type="number"
                    step="0.05"
                    value={customLogP}
                    onChange={(e) => setCustomLogP(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    H-Bond Donors (HBD)
                  </label>
                  <input
                    type="number"
                    value={customHbd}
                    onChange={(e) => setCustomHbd(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    H-Bond Acceptors (HBA)
                  </label>
                  <input
                    type="number"
                    value={customHba}
                    onChange={(e) => setCustomHba(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Chemical Description / Pharmacophore
                </label>
                <textarea
                  rows={2}
                  value={customDesc}
                  onChange={(e) => setCustomDesc(e.target.value)}
                  placeholder="Rationale or functional groups..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCustomModal(false)}
                  className="px-3.5 py-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-semibold"
                >
                  Create & Select Molecule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
