import React from 'react';
import {
  QuantumSimulationConfig,
  QuantumOptimizer,
  NoiseMitigationMethod,
  QuantumAnsatz
} from '../types/docking';
import {
  Zap,
  Sliders,
  Cpu,
  Shield,
  Activity,
  Play,
  CheckCircle2,
  HelpCircle,
  Sparkles,
  Gauge
} from 'lucide-react';

interface QuantumControlPanelProps {
  config: QuantumSimulationConfig;
  onChangeConfig: (config: QuantumSimulationConfig) => void;
  onRunSimulation: () => void;
  isSimulating: boolean;
  simulationProgress: number; // 0 to 100
}

export const QuantumControlPanel: React.FC<QuantumControlPanelProps> = ({
  config,
  onChangeConfig,
  onRunSimulation,
  isSimulating,
  simulationProgress
}) => {
  const updateConfig = <K extends keyof QuantumSimulationConfig>(
    key: K,
    val: QuantumSimulationConfig[K]
  ) => {
    onChangeConfig({
      ...config,
      [key]: val
    });
  };

  return (
    <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5 shadow-2xl space-y-5">
      {/* Panel Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              Quantum Simulation Engine (VQE)
            </h3>
            <p className="text-xs text-slate-400">
              Variational Quantum Eigensolver Hamiltonian Mapping
            </p>
          </div>
        </div>
        <span className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-700/50">
          NISQ Ready
        </span>
      </div>

      {/* 1. Qubit Count Slider */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs">
          <label className="text-slate-300 font-semibold flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            Active Space Qubits:
            <span className="text-cyan-400 font-mono font-bold text-sm ml-1">
              {config.qubits} Qubits
            </span>
          </label>
          <span className="text-[11px] text-slate-400 font-mono">
            {config.qubits * 2} Spin-Orbitals ({config.qubits} HOMO/LUMO)
          </span>
        </div>
        <input
          type="range"
          min={4}
          max={16}
          step={2}
          value={config.qubits}
          disabled={isSimulating}
          onChange={(e) => updateConfig('qubits', parseInt(e.target.value, 10))}
          className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
        />
        <div className="flex justify-between text-[10px] text-slate-500 font-mono px-0.5">
          <span>4 Q (Minimal)</span>
          <span>8 Q (Standard)</span>
          <span>12 Q (Accurate)</span>
          <span>16 Q (High Res)</span>
        </div>
      </div>

      {/* 2. Circuit Depth & Ansatz */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Ansatz Depth */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <label className="text-slate-300 font-semibold">
              Circuit Depth (Layers):
            </label>
            <span className="text-cyan-400 font-mono font-bold text-xs">
              {config.ansatzDepth} Layer{config.ansatzDepth > 1 ? 's' : ''}
            </span>
          </div>
          <input
            type="range"
            min={1}
            max={8}
            step={1}
            value={config.ansatzDepth}
            disabled={isSimulating}
            onChange={(e) => updateConfig('ansatzDepth', parseInt(e.target.value, 10))}
            className="w-full accent-cyan-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] text-slate-500 font-mono block">
            {(config.qubits - 1) * config.ansatzDepth * 2} Entangling CNOT Gates
          </span>
        </div>

        {/* Ansatz Type */}
        <div className="space-y-1.5">
          <label className="text-xs text-slate-300 font-semibold block">
            Ansatz Architecture:
          </label>
          <select
            value={config.ansatz}
            disabled={isSimulating}
            onChange={(e) => updateConfig('ansatz', e.target.value as QuantumAnsatz)}
            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
          >
            <option value="hardware_efficient">Hardware-Efficient (Ry-Rz + CX)</option>
            <option value="uccsd">UCCSD (Unitary Coupled Cluster)</option>
            <option value="ryrz_cx">RealAmplitudes (Linear Entanglement)</option>
          </select>
        </div>
      </div>

      {/* 3. Classical Optimizer & Shots */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <label className="text-xs text-slate-300 font-semibold block">
            Classical Optimizer:
          </label>
          <select
            value={config.optimizer}
            disabled={isSimulating}
            onChange={(e) => updateConfig('optimizer', e.target.value as QuantumOptimizer)}
            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
          >
            <option value="COBYLA">COBYLA (Robust Gradient-Free)</option>
            <option value="SPSA">SPSA (Stochastic for Noisy QPU)</option>
            <option value="Adam">Adam (Adaptive Gradient)</option>
            <option value="SLSQP">SLSQP (Sequential Quadratic)</option>
          </select>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs text-slate-300 font-semibold block">
            Quantum Measurement Shots:
          </label>
          <select
            value={config.shots}
            disabled={isSimulating}
            onChange={(e) => updateConfig('shots', parseInt(e.target.value, 10))}
            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
          >
            <option value={0}>Statevector (Exact / Analytical)</option>
            <option value={1024}>1,024 Shots (Rapid)</option>
            <option value={4096}>4,096 Shots (Recommended)</option>
            <option value={8192}>8,192 Shots (High Precision)</option>
          </select>
        </div>
      </div>

      {/* 4. Noise Level & Error Mitigation */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800/80">
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <label className="text-slate-300 font-semibold">
              Depolarizing Gate Noise:
            </label>
            <span className="text-amber-400 font-mono font-bold text-xs">
              {(config.noiseLevel * 100).toFixed(1)}%
            </span>
          </div>
          <input
            type="range"
            min={0}
            max={0.05}
            step={0.005}
            value={config.noiseLevel}
            disabled={isSimulating}
            onChange={(e) => updateConfig('noiseLevel', parseFloat(e.target.value))}
            className="w-full accent-amber-400 bg-slate-800 h-2 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] text-slate-500 font-mono block">
            Simulates NISQ hardware thermal relaxation & dephasing
          </span>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs text-slate-300 font-semibold flex items-center gap-1">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            Quantum Error Mitigation:
          </label>
          <select
            value={config.noiseMitigation}
            disabled={isSimulating}
            onChange={(e) => updateConfig('noiseMitigation', e.target.value as NoiseMitigationMethod)}
            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-emerald-300 focus:outline-none focus:border-emerald-500 font-mono"
          >
            <option value="none">None (Raw Hardware)</option>
            <option value="zne">Zero-Noise Extrapolation (ZNE)</option>
            <option value="rem">Readout Error Mitigation (REM)</option>
            <option value="cdr">Clifford Data Regression (CDR)</option>
          </select>
        </div>
      </div>

      {/* Execution CTA Button & Progress Bar */}
      <div className="pt-2">
        <button
          onClick={onRunSimulation}
          disabled={isSimulating}
          className={`w-full relative overflow-hidden py-3 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2.5 transition-all shadow-xl ${
            isSimulating
              ? 'bg-slate-800 text-slate-400 cursor-not-allowed border border-slate-700'
              : 'bg-gradient-to-r from-cyan-400 via-teal-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 text-slate-950 shadow-[0_0_25px_rgba(6,182,212,0.35)] active:scale-[0.99]'
          }`}
        >
          {isSimulating ? (
            <>
              <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              <span>Simulating VQE Iterations ({simulationProgress}%)...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>Run Quantum VQE Docking Simulation</span>
            </>
          )}
        </button>

        {/* Progress Bar when running */}
        {isSimulating && (
          <div className="mt-2 w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800">
            <div
              className="bg-gradient-to-r from-cyan-400 to-emerald-400 h-full transition-all duration-150"
              style={{ width: `${simulationProgress}%` }}
            />
          </div>
        )}
      </div>
    </div>
  );
};
