import React from 'react';
import {
  BookOpen,
  X,
  Zap,
  Atom,
  Cpu,
  Layers,
  ShieldCheck,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

interface TheoryDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TheoryDocsModal: React.FC<TheoryDocsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="bg-slate-900 border border-cyan-800/80 rounded-2xl max-w-3xl w-full max-h-[88vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                QuantumDock Scientific Documentation & Theory
              </h3>
              <p className="text-xs text-slate-400">
                Foundations of Variational Quantum Eigensolver (VQE) in Molecular Docking
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-300 leading-relaxed font-sans">
          {/* Section 1: The Core Problem */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-cyan-400 flex items-center gap-2">
              <Atom className="w-4 h-4" />
              1. The Molecular Docking Bottleneck in Drug Discovery
            </h4>
            <p>
              Traditional computational docking uses classical molecular mechanics (e.g. MM-GBSA, AutoDock Vina, CHARMM). These models rely on fixed-point Coulomb electrostatics and empirical Lennard-Jones (12-6) potentials. While computationally fast, classical mechanics ignores <strong>dynamic electron correlation</strong>, quantum mechanical exchange, and orbital hybridization changes that occur when ligands form transient covalent bonds or polarized hydrogen-bonding networks with target protein residues.
            </p>
          </div>

          {/* Section 2: VQE Formulation */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
              <Cpu className="w-4 h-4" />
              2. Variational Quantum Eigensolver (VQE)
            </h4>
            <p>
              VQE is a hybrid quantum-classical algorithm designed for Noisy Intermediate-Scale Quantum (NISQ) devices. The molecular electronic Hamiltonian in the second-quantized active space is mapped into an observable sum of Pauli spin operators via the <strong>Jordan-Wigner transformation</strong>:
            </p>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-cyan-300 overflow-x-auto">
              H = h₀I + ∑ᵢ hᵢ Zᵢ + ∑ᵢⱼ hᵢⱼ ZᵢZⱼ + ∑ᵢⱼ Jᵢⱼ (XᵢXⱼ + YᵢYⱼ)
            </div>
            <p>
              A parameterized quantum circuit (ansatz) prepares a trial quantum state |ψ(θ)⟩. The quantum processor measures the expectation value ⟨ψ(θ)|H|ψ(θ)⟩, and a classical optimizer (such as COBYLA, SPSA, or Adam) iteratively updates the circuit rotation angles θ until it converges to the ground state energy E₀.
            </p>
          </div>

          {/* Section 3: Electronic Correlation Energy */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-purple-400 flex items-center gap-2">
              <Zap className="w-4 h-4" />
              3. Hartree-Fock vs. Electronic Correlation Energy
            </h4>
            <p>
              The Hartree-Fock (HF) approximation accounts for mean-field electron repulsion, but fails to capture the intricate instantaneous avoidance between electrons (correlation). The difference:
            </p>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-purple-300">
              ΔE_corr = E_VQE (FCI) - E_HF
            </div>
            <p>
              In covalent inhibitors (such as Paxlovid attacking SARS-CoV-2 Cys145, or Sotorasib attacking KRAS G12C), electron correlation provides a critical -2.5 to -4.5 kcal/mol stabilization energy. Missing this in classical docking leads to false negatives during high-throughput screening.
            </p>
          </div>

          {/* Section 4: Quantum Error Mitigation */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-amber-400 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4" />
              4. Error Mitigation in NISQ Hardware
            </h4>
            <p>
              Near-term quantum processors experience gate errors and decoherence. QuantumDock models three state-of-the-art error mitigation techniques:
            </p>
            <ul className="list-disc list-inside space-y-1 text-slate-400">
              <li><strong>Zero-Noise Extrapolation (ZNE):</strong> Artificially scales noise levels (pulse stretching or CNOT unitary folding) and extrapolates the expectation value back to the zero-noise limit.</li>
              <li><strong>Readout Error Mitigation (REM):</strong> Inverts the measurement assignment matrix M calibrated on computational basis states.</li>
              <li><strong>Clifford Data Regression (CDR):</strong> Uses classically simulable Clifford circuits to calibrate noise bias.</li>
            </ul>
          </div>

          {/* Section 5: Gemini AI Synthesis */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-cyan-300 flex items-center gap-2">
              <Layers className="w-4 h-4" />
              5. AI Biomolecule Analyst
            </h4>
            <p>
              Gemini AI contextualizes the numerical quantum eigensolver output within pharmacological parameters (Lipinski Rule of 5, bioavailability, blood-brain barrier permeability, and hERG cardiotoxicity). It delivers targeted bioisostere suggestions to empower medicinal chemists in iterative lead optimization cycles.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs">
          <span className="text-slate-400 font-mono">QuantumDock Studio v2.4</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-semibold transition-colors"
          >
            Close Documentation
          </button>
        </div>
      </div>
    </div>
  );
};
