import React from 'react';
import { TargetProtein, LigandCandidate, HydrogenBondInteraction } from '../types/docking';
import { Sparkles, Zap, Shield, ArrowUpRight } from 'lucide-react';

interface Pharmacophore2DProps {
  target: TargetProtein;
  ligand: LigandCandidate;
  interactions: HydrogenBondInteraction[];
}

export const Pharmacophore2D: React.FC<Pharmacophore2DProps> = ({
  target,
  ligand,
  interactions
}) => {
  return (
    <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5 shadow-xl">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-bold text-white tracking-tight">
            2D Pharmacophore & Residue Interaction Map
          </h3>
        </div>
        <span className="text-[11px] font-mono text-cyan-400 px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/50">
          {interactions.length} Active Contact{interactions.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* SVG 2D Diagram */}
      <div className="relative w-full h-64 bg-slate-950 rounded-xl border border-slate-800/80 overflow-hidden flex items-center justify-center p-3">
        <svg className="w-full h-full max-w-lg" viewBox="0 0 500 240">
          <defs>
            {/* Gradients */}
            <radialGradient id="ligandCenterGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#06B6D4" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#06B6D4" stopOpacity="0" />
            </radialGradient>
            <filter id="glowFilter" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Center Ligand Core Ring/Polygon */}
          <circle cx="250" cy="120" r="75" fill="url(#ligandCenterGlow)" />
          <polygon
            points="250,75 295,95 295,145 250,165 205,145 205,95"
            fill="rgba(15,23,42,0.9)"
            stroke="#0284C7"
            strokeWidth="2"
          />
          <circle cx="250" cy="120" r="28" fill="rgba(6,182,212,0.1)" stroke="#38BDF8" strokeWidth="1.5" strokeDasharray="3,3" />

          {/* Ligand Name In Center */}
          <text x="250" y="117" textAnchor="middle" fill="#FFFFFF" fontSize="12" fontWeight="bold" fontFamily="sans-serif">
            {ligand.name}
          </text>
          <text x="250" y="132" textAnchor="middle" fill="#94A3B8" fontSize="9" fontFamily="monospace">
            {ligand.formula}
          </text>

          {/* Render Surrounding Residues and Interaction Lines */}
          {interactions.map((inter, idx) => {
            const count = Math.max(interactions.length, 3);
            const angle = (idx / count) * Math.PI * 2 - Math.PI / 2;
            const resX = 250 + Math.cos(angle) * 175;
            const resY = 120 + Math.sin(angle) * 75;

            // Anchor point on ligand polygon boundary
            const ligAnchorX = 250 + Math.cos(angle) * 55;
            const ligAnchorY = 120 + Math.sin(angle) * 45;

            const isCovalent = inter.type === 'covalent_warhead';
            const isPi = inter.type === 'pi_stacking';
            const lineColor = isCovalent ? '#F43F5E' : isPi ? '#A855F7' : '#38BDF8';

            return (
              <g key={inter.id}>
                {/* Connecting dashed line */}
                <line
                  x1={ligAnchorX}
                  y1={ligAnchorY}
                  x2={resX}
                  y2={resY}
                  stroke={lineColor}
                  strokeWidth="2"
                  strokeDasharray={isCovalent ? '6,3' : '4,3'}
                  filter="url(#glowFilter)"
                />

                {/* Distance pill in middle */}
                <rect
                  x={(ligAnchorX + resX) / 2 - 20}
                  y={(ligAnchorY + resY) / 2 - 8}
                  width="40"
                  height="16"
                  rx="4"
                  fill="#0F172A"
                  stroke={lineColor}
                  strokeWidth="1"
                />
                <text
                  x={(ligAnchorX + resX) / 2}
                  y={(ligAnchorY + resY) / 2 + 3}
                  textAnchor="middle"
                  fill="#FFFFFF"
                  fontSize="8"
                  fontWeight="bold"
                  fontFamily="monospace"
                >
                  {inter.distanceAngstroms} Å
                </text>

                {/* Residue Node Card */}
                <circle cx={resX} cy={resY} r="16" fill={isCovalent ? '#881337' : '#083344'} stroke={lineColor} strokeWidth="1.5" />
                <text
                  x={resX}
                  y={resY + 4}
                  textAnchor="middle"
                  fill="#FFFFFF"
                  fontSize="9"
                  fontWeight="bold"
                  fontFamily="monospace"
                >
                  {inter.donorResidue.slice(0, 6)}
                </text>

                {/* Interaction type label */}
                <text
                  x={resX}
                  y={resY > 120 ? resY + 28 : resY - 20}
                  textAnchor="middle"
                  fill={lineColor}
                  fontSize="8"
                  fontWeight="600"
                  fontFamily="sans-serif"
                >
                  {isCovalent ? '⚡ Covalent Bond' : isPi ? 'π-π Stacking' : 'H-Bond'} ({inter.energyKcalMol} kcal)
                </text>
              </g>
            );
          })}

          {/* If no predefined interactions, show informational placeholder */}
          {interactions.length === 0 && (
            <text x="250" y="195" textAnchor="middle" fill="#64748B" fontSize="10" fontFamily="sans-serif">
              Steric non-covalent van der Waals packing mapped across active cavity.
            </text>
          )}
        </svg>
      </div>

      {/* Interactions Table List */}
      <div className="mt-4 space-y-2">
        {interactions.map((inter) => (
          <div
            key={inter.id}
            className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs font-mono"
          >
            <div className="flex items-center gap-2">
              <span
                className={`w-2 h-2 rounded-full ${
                  inter.type === 'covalent_warhead'
                    ? 'bg-rose-400'
                    : inter.type === 'pi_stacking'
                    ? 'bg-purple-400'
                    : 'bg-cyan-400'
                }`}
              />
              <span className="text-white font-semibold">{inter.donorResidue}</span>
              <span className="text-slate-500">↔</span>
              <span className="text-slate-300">{inter.acceptorAtom}</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-slate-400">{inter.distanceAngstroms} Å</span>
              <span className="text-emerald-400 font-semibold">{inter.energyKcalMol} kcal/mol</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
